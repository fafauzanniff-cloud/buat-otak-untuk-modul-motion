# Font paket Gonanku

Diambil dari repositori resmi google/fonts melalui HTTPS dengan verifikasi TLS tetap aktif.

- Special Elite: Apache License 2.0, lihat SpecialElite-LICENSE.txt.
- Lilita One: SIL Open Font License 1.1, lihat LilitaOne-OFL.txt.

Sumber dan SHA-256 unduhan tercatat di sources.json. Tidak ada modifikasi pada file font. Font ini dipilih untuk mendekati tampilan referensi; bukan klaim identifikasi font asli dari video.
