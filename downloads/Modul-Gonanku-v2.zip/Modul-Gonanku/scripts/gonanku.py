#!/usr/bin/env python3
"""Gonanku: validated storyboards → animated MP4. No LLM or paid API required."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("Pillow belum tersedia. Jalankan: python3 -m pip install -r requirements.txt")

if __package__:
    from . import motion
else:
    import motion

MODEL = "eleven_multilingual_v2"


def text(value, name, maximum):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"{name}: wajib teks 1–{maximum} karakter.")
    if any(ord(c) < 32 and c not in "\n\t" for c in value):
        raise ValueError(f"{name}: karakter kontrol tidak diperbolehkan.")


def strings(value, name, maximum=2000):
    if not isinstance(value, list) or len(value) > 100:
        raise ValueError(f"{name}: wajib daftar, maksimal 100 item.")
    for item in value:
        text(item, name, maximum)


def validate(data):
    if not isinstance(data, dict):
        raise ValueError("Storyboard wajib objek JSON.")
    text(data.get("title"), "title", 150)
    if data.get("format") not in ("portrait", "landscape"):
        raise ValueError("format: pilih portrait atau landscape.")
    preset = data.get("preset", "classic")
    if preset not in motion.PRESETS:
        raise ValueError("preset tidak dikenal. Pilih: " + ", ".join(motion.PRESETS))
    if preset != "classic" and data["format"] != "portrait":
        raise ValueError("Preset referensi dirancang untuk portrait; gunakan classic untuk landscape.")
    if data.get("subtitle_kind", "narration") not in ("narration", "screen_text"):
        raise ValueError("subtitle_kind: pilih narration atau screen_text.")
    if data.get("goal") not in ("iklan", "produk_digital", "komunitas"):
        raise ValueError("goal: pilih iklan, produk_digital, atau komunitas.")
    brand = data.get("brand")
    if not isinstance(brand, dict):
        raise ValueError("brand wajib objek.")
    text(brand.get("name"), "brand.name", 24)
    for key in ("background", "accent", "text"):
        if not isinstance(brand.get(key), str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", brand[key]):
            raise ValueError(f"brand.{key}: gunakan #RRGGBB.")
    # Reject very low contrast combinations to preserve readable motion cards.
    def luminance(color):
        rgb = [int(color[n:n + 2], 16) / 255 for n in (1, 3, 5)]
        linear = [c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4 for c in rgb]
        return sum(c * w for c, w in zip(linear, (.2126, .7152, .0722)))
    for key in (("text", "accent") if preset == "classic" else ()):
        a, b = sorted((luminance(brand[key]), luminance(brand["background"])))
        if (b + .05) / (a + .05) < 3:
            raise ValueError(f"brand.{key}: kontras terhadap background terlalu rendah (minimal 3:1).")
    scenes = data.get("scenes")
    if not isinstance(scenes, list) or not 1 <= len(scenes) <= 60:
        raise ValueError("scenes: wajib 1–60 scene.")
    for n, scene in enumerate(scenes, 1):
        if not isinstance(scene, dict):
            raise ValueError(f"Scene {n}: wajib objek.")
        duration = scene.get("duration")
        if type(duration) not in (int, float) or not math.isfinite(duration) or not .5 <= duration <= 60:
            raise ValueError(f"Scene {n}: duration harus 0,5–60 detik.")
        for key, limit in (("label", 36), ("headline", 100), ("body", 180), ("narration", 1000)):
            text(scene.get(key), f"Scene {n}.{key}", limit)
        if scene.get("visual", "book") not in motion.VISUALS:
            raise ValueError(f"Scene {n}: visual tidak dikenal.")
        if scene.get("layout", "hero") not in motion.LAYOUTS:
            raise ValueError(f"Scene {n}: layout tidak dikenal.")
        for flag in ("show_label", "body_emphasis"):
            if flag in scene and type(scene[flag]) is not bool:
                raise ValueError(f"Scene {n}.{flag}: gunakan true atau false.")
        if "items" in scene:
            strings(scene["items"], f"Scene {n}.items", 50)
            if not 1 <= len(scene["items"]) <= 3:
                raise ValueError(f"Scene {n}: gunakan 1–3 items.")
    if sum(s["duration"] for s in scenes) > 600:
        raise ValueError("Durasi total maksimal 600 detik.")
    post = data.get("post")
    if not isinstance(post, dict):
        raise ValueError("post wajib objek.")
    text(post.get("caption"), "post.caption", 5000)
    strings(post.get("hashtags"), "post.hashtags", 60)
    strings(data.get("sources"), "sources")
    strings(data.get("assumptions"), "assumptions")
    return data


def load(path):
    path = Path(path)
    if path.stat().st_size > 1_000_000:
        raise ValueError("JSON terlalu besar (maksimal 1 MB).")
    return validate(json.loads(path.read_text(encoding="utf-8")))


def font_path(custom=None):
    candidates = [custom] if custom else [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(candidate)
    raise ValueError("Font belum tersedia. Gunakan --font /lokasi/font.ttf.")


def wrap(draw, content, font, width):
    lines = []
    for paragraph in content.splitlines() or [content]:
        line = ""
        for word in paragraph.split():
            if draw.textlength(word, font=font) > width:
                raise ValueError("Satu kata terlalu panjang untuk area teks.")
            trial = (line + " " + word).strip()
            if draw.textlength(trial, font=font) <= width:
                line = trial
            else:
                lines.append(line)
                line = word
        if line:
            lines.append(line)
    return lines


def fit(draw, content, face, start, minimum, width, height):
    for size in range(start, minimum - 1, -1):
        font = ImageFont.truetype(face, size)
        try:
            lines = wrap(draw, content, font, width)
        except ValueError:
            continue
        spacing = math.ceil(size * 1.35)
        if len(lines) * spacing <= height:
            return lines, font, spacing
    raise ValueError("Teks tidak muat. Pendekkan headline/body/label atau ganti font.")


def draw_lines(draw, lines, font, spacing, x, y, color):
    for line in lines:
        draw.text((x, y), line, fill=color, font=font, anchor="lt")
        y += spacing


def scene_card(data, scene, index, width, height, face):
    """Pre-render readable text, then animate the complete card at frame time."""
    if data.get("preset", "classic") != "classic":
        return motion.prepare(data, scene, index, width, height, face)
    image = Image.new("RGBA", (width, height))
    d = ImageDraw.Draw(image)
    brand = data["brand"]
    portrait = height > width
    scale = min(width, height) / 540
    margin = round(width * (.085 if portrait else .07))
    right = round(width * (.86 if portrait else .9))
    available = right - margin
    label_y = round(height * .24)
    bounds = [
        (brand["name"], 20, 13, .09, brand["text"], .05),
        (f"{index + 1:02d} / {len(data['scenes']):02d}", 16, 12, .16, brand["accent"], .04),
        (scene["label"], 17, 12, .24, brand["accent"], .06),
        (scene["headline"], 43 if portrait else 38, 28, .32, brand["text"], .21),
        (scene["body"], 22, 17, .56 if portrait else .58, brand["text"], .16),
    ]
    for content, start, minimum, y, color, room in bounds:
        lines, font, spacing = fit(d, content, face, round(start * scale), max(1, round(minimum * scale)), available, round(height * room))
        draw_lines(d, lines, font, spacing, margin, round(height * y), color)
    d.rounded_rectangle((margin, label_y - round(20 * scale), margin + round(45 * scale), label_y - round(15 * scale)), radius=max(1, round(2 * scale)), fill=brand["accent"])
    return image


def frame(data, card, width, height, local, absolute, total, footage=None):
    if isinstance(card, motion.Scene):
        return motion.frame(card, width, height, local, absolute, total, footage)
    brand = data["brand"]
    image = Image.new("RGB", (width, height), brand["background"])
    d = ImageDraw.Draw(image)
    # Subtle grid and deterministic moving outline; no downloaded assets or random state.
    grid = tuple(min(255, int(brand["background"][n:n + 2], 16) + 10) for n in (1, 3, 5))
    step = max(24, width // 9)
    for x in range(0, width, step):
        d.line((x, 0, x, height), fill=grid)
    for y in range(0, height, step):
        d.line((0, y, width, y), fill=grid)
    radius = round(width * (.29 + .018 * math.sin(absolute * 1.6)))
    cx, cy = round(width * .95), round(height * .16)
    d.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), outline=grid, width=max(2, width // 180))
    ease = 1 - (1 - min(1, local / .45)) ** 3
    offset = round((1 - ease) * height * .025)
    image.paste(card, (0, offset), card)
    margin = round(width * .085)
    y = round(height * .79)
    d.rounded_rectangle((margin, y, width - margin, y + max(4, width // 80)), radius=2, fill=grid)
    progress = max(1, round((width - margin * 2) * min(1, absolute / total)))
    d.rounded_rectangle((margin, y, margin + progress, y + max(4, width // 80)), radius=2, fill=brand["accent"])
    return image


def dimensions(data, width=None):
    width = width or (1080 if data["format"] == "portrait" else 1920)
    if not 320 <= width <= 1920 or width % 2:
        raise ValueError("--width harus bilangan genap 320–1920.")
    ratio = 16 / 9 if data["format"] == "portrait" else 9 / 16
    return width, round(width * ratio / 2) * 2


def timestamp(seconds):
    ms = round(seconds * 1000)
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def probe(path):
    result = subprocess.run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path)], capture_output=True, text=True, check=True)
    return json.loads(result.stdout)


def ensure_tools():
    for command in ("ffmpeg", "ffprobe"):
        if not shutil.which(command):
            raise ValueError(f"{command} belum tersedia. Pasang FFmpeg dahulu.")


def render(data, args):
    ensure_tools()
    width, height = dimensions(data, args.width)
    face = font_path(args.font)
    out = Path(args.out).resolve()
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError("Folder output sudah berisi file. Gunakan folder baru untuk revisi.")
    audio = Path(args.audio).resolve() if args.audio else None
    footage_arg = getattr(args, "footage", None)
    footage = Path(footage_arg).resolve() if footage_arg else None
    footage_start = getattr(args, "footage_start", 0)
    presenter = data.get("preset") == "presenter-hangat"
    if presenter and not footage:
        raise ValueError("presenter-hangat memerlukan --footage rekaman.mp4. Gunakan rekaman presenter yang ingin diedit.")
    if footage and not presenter:
        raise ValueError("--footage hanya tersedia untuk preset presenter-hangat.")
    if not math.isfinite(footage_start) or footage_start < 0:
        raise ValueError("--footage-start harus angka positif atau nol.")
    ends = [0]
    seconds = 0
    for scene in data["scenes"]:
        seconds += scene["duration"]
        ends.append(round(seconds * args.fps))
    total = ends[-1] / args.fps
    footage_audio = False
    if footage:
        info = probe(footage)
        if not any(s["codec_type"] == "video" for s in info["streams"]):
            raise ValueError("File footage tidak memiliki video.")
        if float(info["format"]["duration"]) + .05 < total + footage_start:
            raise ValueError("Durasi footage tidak cukup untuk storyboard dan footage-start.")
        footage_audio = not audio and any(s["codec_type"] == "audio" for s in info["streams"])
    if audio:
        info = probe(audio)
        if not any(s["codec_type"] == "audio" for s in info["streams"]):
            raise ValueError("File tidak berisi stream audio.")
        length = float(info["format"]["duration"])
        if not math.isfinite(length) or abs(length - total) > .5:
            raise ValueError(f"Durasi audio {length:.2f}s; storyboard {total:.2f}s. Sesuaikan durasi scene (toleransi 0,5s).")
    cards = [scene_card(data, scene, n, width, height, face) for n, scene in enumerate(data["scenes"])]
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".gonanku-", dir=out.parent) as temporary:
        folder = Path(temporary)
        video = folder / "video.mp4"
        command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}", "-r", str(args.fps), "-i", "pipe:0"]
        if audio or footage_audio:
            if footage_audio:
                command += ["-ss", str(footage_start)]
            command += ["-i", str(audio or footage), "-map", "0:v:0", "-map", "1:a:0", "-af", "apad", "-c:a", "aac", "-b:a", "192k"]
        command += ["-c:v", "libx264", "-threads", "2", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-t", str(total), "-movflags", "+faststart", str(video)]
        with tempfile.TemporaryFile() as errors:
            reader = None
            if footage:
                reader = subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-threads", "2", "-ss", str(footage_start), "-i", str(footage), "-vf", f"fps={args.fps},scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280", "-threads", "2", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"], stdout=subprocess.PIPE, stderr=errors)
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=errors)
            cover = None
            try:
                for n, card in enumerate(cards):
                    for f in range(ends[n], ends[n + 1]):
                        source = None
                        if reader:
                            raw = reader.stdout.read(720 * 1280 * 3)
                            if len(raw) != 720 * 1280 * 3:
                                raise ValueError("Pembacaan footage berhenti sebelum storyboard selesai.")
                            source = Image.frombytes("RGB", (720, 1280), raw)
                        img = frame(data, card, width, height, (f - ends[n]) / args.fps, f / args.fps, total, source)
                        if f == min(round(args.fps * 1.5), ends[1] - 2):
                            cover = img.copy()
                        process.stdin.write(img.tobytes())
                process.stdin.close()
                code = process.wait()
                if code:
                    errors.seek(0)
                    raise ValueError("FFmpeg gagal: " + errors.read(3000).decode(errors="replace"))
            except BaseException:
                if process.stdin and not process.stdin.closed:
                    process.stdin.close()
                if process.poll() is None:
                    process.terminate()
                process.wait()
                raise
            finally:
                if reader:
                    reader.stdout.close()
                    if reader.poll() is None:
                        reader.terminate()
                    reader.wait()
        (cover or frame(data, cards[0], width, height, 1.5, 0, total)).save(folder / "cover.png")
        subtitles = []
        for n, scene in enumerate(data["scenes"]):
            subtitles.append(f"{n + 1}\n{timestamp(ends[n] / args.fps)} --> {timestamp(ends[n + 1] / args.fps)}\n{scene['narration']}\n")
        (folder / "captions.srt").write_text("\n".join(subtitles), encoding="utf-8")
        (folder / "naskah.txt").write_text("\n\n".join(s["narration"] for s in data["scenes"]), encoding="utf-8")
        upload = f"# {data['title']}\n\nStatus: DRAFT, belum dipublikasikan.\n\nPreset: {data.get('preset', 'classic')}\n\nTujuan: {data['goal']}\n\n{data['post']['caption']}\n\n{' '.join(data['post']['hashtags'])}\n\nAudio: {'tersedia; periksa sinkronisasi per scene' if audio or footage_audio else 'TANPA SUARA'}\n\n## Asumsi\n\n" + "\n".join("- " + a for a in data["assumptions"]) + "\n\n## Sumber\n\n" + "\n".join("- " + s for s in data["sources"]) + "\n"
        (folder / "upload.md").write_text(upload, encoding="utf-8")
        metadata = probe(video)
        stream = next(s for s in metadata["streams"] if s["codec_type"] == "video")
        if int(stream["nb_frames"]) != ends[-1]:
            raise ValueError("Frame keluaran tidak sesuai storyboard.")
        manifest = {"module": "Modul Gonanku", "version": "2.0", "preset": data.get("preset", "classic"), "title": data["title"], "width": width, "height": height, "fps": args.fps, "frames": ends[-1], "duration_seconds": total, "audio": audio is not None or footage_audio, "subtitle_timing": "scene", "subtitle_kind": data.get("subtitle_kind", "narration"), "sha256": hashlib.sha256(video.read_bytes()).hexdigest()}
        (folder / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        out.mkdir(exist_ok=True)
        for file in folder.iterdir():
            shutil.move(str(file), out / file.name)
    print(f"Selesai: {out / 'video.mp4'} ({total:.2f}s; {'dengan audio' if audio or footage_audio else 'tanpa suara'})")


def voice(data, args):
    narration = "\n\n".join(s["narration"] for s in data["scenes"])
    print(f"Model: {MODEL}; {len(narration)} karakter. Biaya mengikuti model/paket ElevenLabs.")
    if not args.execute:
        print("DRY RUN: tidak mengakses jaringan, tidak memakai kredit. Tambahkan --execute hanya jika ingin membuat suara.")
        return
    if len(narration) > 10000:
        raise ValueError("Narasi melebihi 10.000 karakter; pecah proyek sebelum TTS.")
    key = os.environ.get("ELEVENLABS_API_KEY")
    voice_id = os.environ.get("ELEVENLABS_VOICE_ID")
    if not key or not voice_id:
        raise ValueError("Set ELEVENLABS_API_KEY dan ELEVENLABS_VOICE_ID lewat pengaturan aman, bukan chat.")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", voice_id):
        raise ValueError("ELEVENLABS_VOICE_ID tidak valid.")
    out = Path(args.out)
    if out.exists():
        raise ValueError("File audio sudah ada; gunakan --out baru agar tidak memakai kredit ulang tanpa sengaja.")
    payload = json.dumps({"text": narration, "model_id": MODEL}).encode()
    request = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}?output_format=mp3_44100_128", data=payload, headers={"xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg"})
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        # Do not forward the credential header to a different destination.
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None

    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(request, timeout=180) as response:
            if not response.headers.get("Content-Type", "").lower().startswith("audio/"):
                raise ValueError("ElevenLabs tidak mengembalikan audio; respons tidak disimpan.")
            content = response.read(50_000_001)
    except urllib.error.HTTPError as error:
        raise ValueError(f"ElevenLabs HTTP {error.code}; periksa izin key, voice, paket, dan kuota. Nilai key tidak ditampilkan.") from None
    except urllib.error.URLError:
        raise ValueError("Koneksi ElevenLabs gagal. Periksa proxy, TLS, dan izin domain api.elevenlabs.io; jangan menonaktifkan verifikasi TLS.") from None
    if not content or len(content) > 50_000_000:
        raise ValueError("Audio kosong atau melebihi batas 50 MB.")
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("xb") as destination:
        destination.write(content)
    print(f"Audio disimpan: {out}. Dengarkan dan sesuaikan durasi tiap scene sebelum render.")


def doctor(args):
    print(f"Python: {sys.version.split()[0]}; Pillow: tersedia")
    ensure_tools()
    print("FFmpeg dan ffprobe: tersedia")
    encoders = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True, check=True).stdout
    if "libx264" not in encoders:
        raise ValueError("FFmpeg tidak memiliki encoder libx264.")
    print("Encoder H.264: tersedia")
    font_path(args.font)
    print("Font: tersedia")
    for name in ("ELEVENLABS_API_KEY", "ELEVENLABS_VOICE_ID"):
        print(f"{name}: {'terpasang (belum diuji online)' if os.environ.get(name) else 'belum diisi, opsional'}")
    print("Siap render tanpa API. Doctor tidak menguji koneksi ElevenLabs.")


def main():
    parser = argparse.ArgumentParser(description="Modul Gonanku — storytelling edukatif menjadi motion video")
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("doctor")
    check.add_argument("--font")
    commands.add_parser("validate").add_argument("storyboard")
    rendering = commands.add_parser("render")
    rendering.add_argument("storyboard")
    rendering.add_argument("--width", type=int)
    rendering.add_argument("--fps", type=int, choices=(24, 25, 30), default=30)
    rendering.add_argument("--font")
    rendering.add_argument("--audio")
    rendering.add_argument("--footage", help="rekaman asli untuk preset presenter-hangat; audio asli dipakai jika --audio tidak diberikan")
    rendering.add_argument("--footage-start", type=float, default=0, help="posisi mulai footage dalam detik")
    rendering.add_argument("--out", default="output/video")
    tts = commands.add_parser("voice")
    tts.add_argument("storyboard")
    tts.add_argument("--execute", action="store_true")
    tts.add_argument("--out", default="output/narasi.mp3")
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            doctor(args)
        else:
            data = load(args.storyboard)
            if args.command == "validate":
                print(f"Valid: {len(data['scenes'])} scene, {sum(s['duration'] for s in data['scenes']):g} detik.")
            elif args.command == "voice":
                voice(data, args)
            else:
                render(data, args)
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(f"Gagal: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
