"""Build a reviewable Gonanku ZIP from an explicit list; never include secrets."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = ["README.md", "MULAI-DI-SINI.md", "AGENTS.md", ".gitignore", "requirements.txt"]
FOLDERS = ["chatgpt", "docs", "brand", "examples", "scripts", "tests", "references", "assets"]


def main():
    paths = [ROOT / file for file in FILES]
    for folder in FOLDERS:
        paths.extend(p for p in (ROOT / folder).rglob("*") if p.is_file() and p.suffix in (".md", ".json", ".py", ".txt", ".jpg", ".png", ".ttf"))
    demos = {"koran": "v2-koran", "aurora": "v2-aurora", "kartun": "v2-cosmic"}
    expected = ["video.mp4", "cover.png", "captions.srt", "naskah.txt", "upload.md", "manifest.json"]
    for demo in demos.values():
        if not all((ROOT / "output" / demo / name).is_file() for name in expected):
            raise SystemExit(f"Render contoh v2 dahulu: output/{demo}.")
    target = ROOT / "dist/Modul-Gonanku-v2.zip"
    target.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(paths):
            archive.write(path, Path("Modul-Gonanku") / path.relative_to(ROOT))
        for label, demo in demos.items():
            for name in expected:
                archive.write(ROOT / "output" / demo / name, f"Modul-Gonanku/contoh-hasil/{label}/{name}")
    print(target)


if __name__ == "__main__":
    main()
