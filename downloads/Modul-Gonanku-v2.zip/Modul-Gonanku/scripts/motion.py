"""Reusable reference-inspired motion direction. All illustrations drawn locally."""
from dataclasses import dataclass
import math
from pathlib import Path
import random

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

PRESETS = ("classic", "koran-vintage", "aurora-story", "cosmic-cartoon", "presenter-hangat")
VISUALS = ("lantern", "gears", "track", "care", "pot", "recipe", "quote", "gauge", "shield", "moon", "checklist", "road", "chat", "cards", "book")
LAYOUTS = ("hero", "statement", "quote", "checklist", "split", "recipe")
PALETTES = {
    "koran-vintage": ("#d8d1bd", "#8b3429", "#29271f"),
    "aurora-story": ("#03151c", "#46edb5", "#e5f8ef"),
    "cosmic-cartoon": ("#101735", "#f7d76c", "#fbf0ce"),
    "presenter-hangat": ("#160f0a", "#eedbb1", "#fff2d7"),
}
FONT_DIR = Path(__file__).resolve().parents[1] / "assets" / "fonts"


def ease(t):
    return 1 - (1 - max(0, min(1, t))) ** 3


def font(face, size, serif=False, italic=False, mono=False):
    filename = "DejaVuSansMono.ttf" if mono else ("DejaVuSerif-Italic.ttf" if italic else "DejaVuSerif.ttf") if serif else "DejaVuSans-Bold.ttf"
    # Honour a custom font for sans; look for companion serif/mono fonts when needed.
    choices = [Path(face).parent / filename, Path("/usr/share/fonts/truetype/dejavu") / filename]
    if serif and not italic and not mono:
        choices.insert(0, FONT_DIR / "SpecialElite-Regular.ttf")
    if not (serif or mono):
        choices.insert(0, Path(face))
    choices.append(Path(face))
    return ImageFont.truetype(str(next(p for p in choices if p.is_file())), max(8, int(size)))


def textbox(content, face, size, width, color, *, serif=False, italic=False, center=False, maximum_height=None, mono=False):
    """Fit a bounded block without cutting a long word or overflowing vertically."""
    content = content.strip()
    for s in range(size, min(size, max(8, int(size * .68))) - 1, -1):
        f = font(face, s, serif, italic, mono)
        dummy = ImageDraw.Draw(Image.new("RGB", (1, 1)))
        lines = []
        valid = True
        for paragraph in content.splitlines():
            line = ""
            for word in paragraph.split():
                if dummy.textlength(word, font=f) > width:
                    valid = False
                    break
                trial = (line + " " + word).strip()
                if dummy.textlength(trial, font=f) > width:
                    lines.append(line)
                    line = word
                else:
                    line = trial
            if line:
                lines.append(line)
        lineheight = round(s * 1.35)
        if valid and (maximum_height is None or len(lines) * lineheight <= maximum_height):
            im = Image.new("RGBA", (width, max(1, len(lines) * lineheight + 6)))
            d = ImageDraw.Draw(im)
            for n, line in enumerate(lines):
                x = (width - d.textlength(line, font=f)) / 2 if center else 0
                d.text((x, n * lineheight + 2), line, font=f, fill=color, anchor="lt")
            return im
    raise ValueError("Teks preset tidak muat. Pendekkan teks atau gunakan baris baru.")


def glow_background(style, seed, warm=False):
    paper = style == "koran-vintage"
    base, accent, ink = PALETTES[style]
    rng = random.Random(seed)
    if paper:
        small = Image.new("RGB", (180, 320))
        pixels = small.load()
        for y in range(320):
            for x in range(180):
                edge = (abs(x - 90) / 90) ** 4 + (abs(y - 160) / 160) ** 6
                noise = rng.randrange(-7, 8)
                pixels[x, y] = tuple(max(0, min(255, c + noise - round(edge * 18))) for c in (219, 212, 193))
    else:
        rgb = tuple(int(base[i:i + 2], 16) for i in (1, 3, 5))
        small = Image.new("RGB", (180, 320))
        pixels = small.load()
        for y in range(320):
            for x in range(180):
                if style == "aurora-story":
                    green = math.exp(-(((x - 160) / 115) ** 2 + ((y - 35) / 90) ** 2)) * .36 + math.exp(-(((x - 75) / 140) ** 2 + ((y - 345) / 80) ** 2)) * .8
                    blue = math.exp(-(((x - 5) / 90) ** 2 + ((y - 160) / 120) ** 2)) * .22
                    if warm:
                        gold = math.exp(-(((x - 90) / 85) ** 2 + ((y - 150) / 80) ** 2))
                        colors = (rgb[0] + gold * 180, rgb[1] + gold * 121, rgb[2] + gold * 18)
                    else:
                        colors = (rgb[0] + green * 8, rgb[1] + green * 160 + blue * 20, rgb[2] + green * 110 + blue * 130)
                elif style == "cosmic-cartoon":
                    light = math.exp(-(((x - 90) / 120) ** 2 + ((y - 150) / 170) ** 2))
                    colors = (rgb[0] + light * 14, rgb[1] + light * 20, rgb[2] + light * 36)
                else:
                    light = math.exp(-(((x - 95) / 120) ** 2 + ((y - 180) / 130) ** 2))
                    colors = (rgb[0] + light * 35, rgb[1] + light * 26, rgb[2] + light * 13)
                pixels[x, y] = tuple(max(0, min(255, round(c))) for c in colors)
    return small.resize((720, 1280), Image.Resampling.BICUBIC)


def newspaper(seed, face):
    im = glow_background("koran-vintage", seed)
    d = ImageDraw.Draw(im)
    rng = random.Random(seed)
    words = ["belajar", "cerita", "perubahan", "langkah", "catatan", "bersama", "waktu", "pengalaman", "perjalanan", "kehidupan"]
    f = font(face, 8, serif=True)
    for col in range(5):
        x = 24 + col * 138
        for row in range(100):
            y = 100 + row * 12
            line = " ".join(rng.choices(words, k=3))
            d.text((x, y), line[:28], font=f, fill=(151, 146, 131))
        d.line((x - 8, 100, x - 8, 1210), fill=(183, 176, 157))
    # Fade print behind the story, retain newspaper columns at the edges.
    wash = Image.new("RGBA", im.size)
    wd = ImageDraw.Draw(wash)
    wd.rectangle((10, 140, 710, 1190), fill=(219, 213, 195, 100))
    wash = wash.filter(ImageFilter.GaussianBlur(25))
    im.paste(wash, (0, 0), wash)
    return im


def illustration(kind, style, face):
    """Original vector-like artwork; no pixels taken from the uploaded references."""
    im = Image.new("RGBA", (620, 470))
    d = ImageDraw.Draw(im)
    paper = style == "koran-vintage"
    dark = (55, 53, 44, 255) if paper else (21, 50, 64, 255)
    light = (218, 208, 177, 255) if paper else (195, 250, 222, 255)
    accent = PALETTES[style][1]
    if kind in ("lantern", "book"):
        d.rounded_rectangle((18, 8, 602, 460), 14, fill=(81, 77, 62, 245) if paper else (14, 32, 58, 255))
        for x in (80, 400):
            d.rounded_rectangle((x, 60, x + 145, 410), radius=70, fill=(44, 43, 36, 255))
        if kind == "lantern":
            glow = Image.new("RGBA", im.size)
            gd = ImageDraw.Draw(glow)
            gd.ellipse((175, 110, 445, 430), fill=(250, 214, 118, 110))
            glow = glow.filter(ImageFilter.GaussianBlur(42))
            im = Image.alpha_composite(im, glow)
            d = ImageDraw.Draw(im)
            d.line((310, 0, 310, 125), fill=dark, width=5)
            d.ellipse((292, 110, 328, 145), outline=dark, width=6)
            d.polygon([(242, 162), (378, 162), (360, 340), (260, 340)], fill=light, outline=dark)
            d.rectangle((235, 150, 385, 170), fill=dark)
            d.rectangle((250, 330, 370, 350), fill=dark)
            for x in (250, 280, 340, 370):
                d.line((x, 164, 310 + (x - 310) * .72, 337), fill=dark, width=5)
        else:
            d.polygon([(112, 155), (305, 185), (310, 360), (110, 330)], fill=light)
            d.polygon([(310, 185), (510, 155), (510, 330), (310, 360)], fill=(234, 225, 197, 255))
            for y in range(200, 310, 24):
                d.line((140, y, 275, y + 18), fill=dark, width=3)
                d.line((342, y + 18, 475, y), fill=dark, width=3)
    elif kind == "gears":
        for cx, cy, r in ((220, 240, 100), (410, 130, 73), (430, 335, 63)):
            for n in range(12):
                a = n * math.tau / 12
                x, y = cx + math.cos(a) * r, cy + math.sin(a) * r
                d.ellipse((x - 20, y - 20, x + 20, y + 20), fill=dark)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=dark)
            d.ellipse((cx - r * .7, cy - r * .7, cx + r * .7, cy + r * .7), outline=light, width=12)
            d.ellipse((cx - r * .23, cy - r * .23, cx + r * .23, cy + r * .23), fill=light)
    elif kind == "track":
        d.rounded_rectangle((30, 35, 590, 440), radius=195, fill="#54584a", outline=dark, width=9)
        for n in range(5):
            a = 55 + 17 * n
            d.rounded_rectangle((a, a - 15, 620 - a, 475 - a), radius=170 - n * 15, outline="#b1a78b" if n != 2 else accent, width=4)
        d.rectangle((190, 150, 430, 325), outline=light, width=3)
        d.line((310, 150, 310, 325), fill=light, width=3)
        d.ellipse((270, 196, 350, 276), outline=light, width=3)
    elif kind == "care":
        d.rounded_rectangle((65, 235, 415, 375), 20, fill=light, outline=dark, width=6)
        d.rectangle((65, 325, 415, 375), fill="#b8ab88")
        d.ellipse((85, 215, 215, 280), fill="#eee1bd", outline=dark, width=4)
        d.rounded_rectangle((110, 70, 140, 200), 13, fill="#efe4cd", outline=dark, width=4)
        d.ellipse((105, 175, 145, 215), fill=accent)
        d.line((125, 100, 125, 185), fill=accent, width=8)
        d.polygon([(455, 200), (560, 200), (545, 390), (470, 390)], fill="#dcd8c7", outline=dark)
        for x, y in ((240, 130), (290, 120), (250, 175), (300, 165)):
            d.ellipse((x, y, x + 29, y + 17), fill=light, outline=dark, width=2)
    elif kind == "pot":
        d.rounded_rectangle((15, 5, 605, 465), 15, fill="#514d3f")
        d.polygon([(105, 420), (145, 300), (475, 300), (515, 420)], fill="#24241e", outline=light)
        d.ellipse((130, 238, 490, 342), fill="#1e201b", outline=light, width=3)
        d.ellipse((145, 248, 475, 325), fill="#79513a", outline="#191b16", width=5)
        for x, y in ((210, 270), (285, 280), (360, 265), (415, 290)):
            d.ellipse((x - 15, y - 8, x + 15, y + 8), fill="#39291f")
        for x in (235, 310, 385):
            points = [(x + math.sin(i * .25) * 14, 220 - i * 5) for i in range(30)]
            d.line(points, fill="#b8ad91", width=3)
    elif kind in ("shield", "checklist"):
        d.polygon([(310, 40), (465, 112), (449, 295), (310, 415), (171, 295), (155, 112)], fill=accent)
        d.polygon([(310, 70), (432, 130), (418, 280), (310, 375), (202, 280), (188, 130)], fill="#20b88e")
        d.polygon([(310, 95), (404, 142), (390, 262), (310, 335), (230, 262), (215, 142)], fill="#63e5b1")
        d.polygon([(327, 145), (265, 255), (308, 246), (288, 315), (365, 210), (320, 216)], fill="#10544c")
    elif kind == "moon":
        d.ellipse((205, 115, 415, 325), fill=light)
        d.ellipse((278, 70, 450, 255), fill=PALETTES[style][0])
        for x, y in ((130, 150), (440, 340), (480, 90)):
            d.line((x - 9, y, x + 9, y), fill=light, width=2)
            d.line((x, y - 9, x, y + 9), fill=light, width=2)
    elif kind in ("recipe", "quote", "cards"):
        d.rounded_rectangle((90, 55, 530, 430), 8, fill=light, outline=dark, width=3)
        d.line((125, 120, 495, 120), fill=dark, width=3)
        for i in range(3):
            y = 175 + i * 75
            d.ellipse((126, y - 12, 162, y + 24), outline=accent, width=3)
            d.line((135, y + 5, 142, y + 13, 156, y - 3), fill=accent, width=4)
            d.line((185, y, 460 - i * 30, y), fill=dark, width=5)
            d.line((185, y + 18, 380, y + 18), fill=dark, width=2)
    else:
        # A locally drawn cartoon landscape, also used inside the chat demo.
        d.rounded_rectangle((0, 0, 620, 470), 14, fill="#132747")
        for x, y, r in ((20, 40, 2), (110, 80, 3), (180, 25, 2), (295, 48, 2), (570, 80, 3)):
            d.ellipse((x - r, y - r, x + r, y + r), fill=light)
        d.ellipse((440, 45, 515, 120), fill="#f9e5a1")
        for x in (462, 490):
            d.ellipse((x, 76, x + 4, 82), fill=dark)
        d.arc((468, 75, 494, 97), 10, 170, fill=dark, width=2)
        for x, size in ((-20, 170), (210, 200), (410, 140)):
            d.polygon([(x, 310), (x + size / 2, 310 - size), (x + size, 310)], fill="#45597b")
            d.polygon([(x + size * .32, 310 - size * .64), (x + size / 2, 310 - size), (x + size * .67, 310 - size * .64)], fill="#c2cfdb")
        d.rectangle((0, 320, 620, 400), fill="#172c33")
        d.rectangle((0, 400, 620, 470), fill="#384455")
        for x in range(0, 620, 110):
            d.line((x, 438, x + 60, 438), fill=light, width=4)
        for x in (50, 150, 380, 545):
            d.rectangle((x, 295, x + 9, 360), fill="#715b41")
            d.polygon([(x - 27, 315), (x + 5, 250), (x + 38, 315)], fill="#347e68")
    return im


@dataclass
class Layer:
    image: Image.Image
    x: int
    y: int
    at: float = 0
    motion: str = "rise"
    angle: float = 0
    zoom: float = 0


@dataclass
class Scene:
    background: Image.Image
    layers: list
    style: str
    visual: str
    seed: int
    duration: float
    footage: bool = False


def prepare(data, scene, index, width, height, face):
    style = data["preset"]
    if style == "cosmic-cartoon" and (FONT_DIR / "LilitaOne-Regular.ttf").is_file():
        face = str(FONT_DIR / "LilitaOne-Regular.ttf")
    visual = scene.get("visual", "book")
    layout = scene.get("layout", "hero")
    paper = style == "koran-vintage"
    base, accent, ink = PALETTES[style]
    layers = []
    bg = newspaper(88, face) if paper else glow_background(style, 88, visual == "gauge")
    def add(im, x, y, at=0, motion="rise", angle=0, zoom=0):
        layers.append(Layer(im, round(x), round(y), at, motion, angle, zoom))
    def txt(content, x, y, size, w=600, color=ink, at=.1, serif=paper, italic=False, center=False, room=180, motion="rise"):
        im = textbox(content, face, size, w, color, serif=serif, italic=italic, center=center, maximum_height=room)
        add(im, x, y, at, motion)
        return im.height
    # The reference's brand/episode masthead becomes Gonanku's own reusable brand.
    txt(f"{data['brand']['name'].upper()}   /   {index + 1:02d}", 40, 58, 14, 640, at=0, center=True, room=30, motion="fade")
    if paper:
        bd = ImageDraw.Draw(bg)
        bd.line((22, 45, 698, 45), fill=ink, width=2)
        bd.line((22, 94, 698, 94), fill=ink, width=2)
        bd.rectangle((24, 1180, 696, 1227), fill="#ded8c6", outline="#8d8774", width=1)
        txt("CATATAN CERITA  •  MODUL GONANKU", 40, 1194, 12, 640, center=True, at=0, room=22, motion="fade")
    else:
        txt("EDUKASI  /  STORYTELLING", 60, 1200, 10, 600, center=True, at=0, room=25, motion="fade")

    if style == "presenter-hangat":
        # Transparent title/graphic overlay is composited onto an actual clip at render time.
        title = textbox(scene["headline"], face, 49, 610, ink, center=True, maximum_height=160)
        panel = Image.new("RGBA", (660, title.height + 65))
        pd = ImageDraw.Draw(panel)
        pd.rounded_rectangle((0, 0, 659, panel.height - 1), 16, fill=(23, 16, 8, 205), outline=(238, 219, 177, 100), width=2)
        panel.paste(title, (25, 28), title)
        add(panel, 30, 125, .12, "pop")
        if layout != "statement":
            art = illustration(visual, style, face).resize((225, 172), Image.Resampling.LANCZOS)
            card = Image.new("RGBA", (245, 230), "#eedbb1")
            card.paste(art, (10, 10), art)
            tag = textbox(scene["label"], face, 15, 225, "#21170e", center=True, maximum_height=44)
            card.paste(tag, (10, 189), tag)
            add(card, 425 if index % 2 else 40, 375, .6, "slide", -8 if index % 2 else 7)
        txt(scene["body"], 75, 925, 28, 570, center=True, room=140, at=1)
        return Scene(bg, layers, style, visual, index, scene["duration"], True)

    if paper:
        tag = textbox(scene["label"].upper(), face, 17, 610, "#e8e1ce", maximum_height=50)
        band = Image.new("RGBA", (min(640, max(200, len(scene["label"]) * 13)), 38), ink)
        band.paste(tag, (9, 6), tag)
        add(band, 43, 157, .05, "wipe")
        if layout == "statement":
            txt(scene["body"], 48, 267, 32, 620, italic=True, room=170, at=.1)
            txt(scene["headline"], 45, 490, 78, 630, color=accent, room=345, at=.55)
            rule = Image.new("RGBA", (600, 3), ink)
            add(rule, 50, 865, 1, "wipe")
        elif layout == "quote":
            txt(scene["headline"], 45, 246, 42, 630, room=180, at=.1)
            card = Image.new("RGBA", (622, 295), "#e5dfce")
            cd = ImageDraw.Draw(card)
            cd.line((25, 25, 595, 25), fill=ink, width=2)
            q = textbox('“' + scene["body"] + '”', face, 40, 550, ink, serif=True, italic=True, maximum_height=230)
            card.paste(q, (36, 55), q)
            add(card, 48, 540, .6, "pop", -3)
        elif layout in ("recipe", "checklist"):
            card = Image.new("RGBA", (612, 850), "#e4decc")
            cd = ImageDraw.Draw(card)
            cd.line((30, 100, 580, 100), fill=ink, width=2)
            add(card, 53, 230, .1, "slide", 1)
            txt(scene["headline"], 90, 265, 48, 535, room=160, at=.3)
            items = scene.get("items", ["Pilih satu langkah", "Lakukan dengan sadar", "Evaluasi dan ulangi"])
            for i, item in enumerate(items):
                y = 480 + i * 152
                badge = Image.new("RGBA", (58, 58))
                bd = ImageDraw.Draw(badge)
                bd.ellipse((1, 1, 56, 56), outline=ink, width=2)
                bd.line((15, 30, 26, 41, 45, 16), fill=accent, width=4)
                add(badge, 89, y, .7 + i * .5, "pop")
                txt(item, 167, y + 3, 27, 425, room=105, at=.8 + i * .5)
            txt(scene["body"], 92, 995, 22, 525, italic=True, room=90, at=2.1)
        else:
            txt(scene["headline"], 45, 760 if layout == "split" else 229, 64, 630, room=190, at=.65 if layout == "split" else .1)
            art = illustration(visual, style, face)
            # Ragged edges create the newspaper-cutout treatment.
            mask = Image.new("L", art.size, 255)
            md = ImageDraw.Draw(mask)
            rng = random.Random(120 + index)
            for x in range(0, 620, 15):
                md.ellipse((x - 9, -9, x + 10, rng.randrange(8, 20)), fill=0)
                md.ellipse((x - 9, 450, x + 11, 483), fill=0)
            art.putalpha(ImageChops.multiply(art.getchannel("A"), mask))
            add(art, 50, 230 if layout == "split" else 450, .1 if layout == "split" else .4, "pop", -1.5, .025)
            txt(scene["body"], 47, 970, 29, 626, italic=True, room=160, at=1)
    elif style == "aurora-story":
        if scene.get("show_label", True):
            txt(scene["label"].upper(), 60, 210, 16, 600, center=True, room=50, color=accent, at=.1)
        if layout == "statement":
            txt(scene["headline"], 60, 445, 54, 600, center=True, room=230, at=.2)
            txt(scene["body"], 60, 750, 64 if scene.get("body_emphasis") else 30, 600, color=accent, center=True, room=230, at=1)
        elif layout == "checklist":
            txt(scene["headline"], 60, 295, 36, 600, center=True, room=125, at=.1)
            card = Image.new("RGBA", (610, 470))
            cd = ImageDraw.Draw(card)
            cd.rounded_rectangle((0, 0, 609, 469), 22, fill=(8, 44, 48, 185), outline=(66, 227, 176, 90), width=2)
            add(card, 55, 480, .4, "pop")
            for i, item in enumerate(scene.get("items", ["Satu langkah kecil", "Satu waktu khusus", "Ulangi besok"])):
                y = 540 + i * 120
                badge = Image.new("RGBA", (45, 45))
                bd = ImageDraw.Draw(badge)
                bd.rounded_rectangle((1, 1, 43, 43), 6, outline=accent, width=2)
                bd.line((10, 23, 19, 31, 35, 12), fill=accent, width=3)
                add(badge, 88, y, .7 + i * .5, "pop")
                txt(item, 155, y, 25, 460, room=90, at=.8 + i * .5)
            txt(scene["body"], 70, 1020, 26, 580, center=True, room=130, at=2)
        else:
            txt(scene["headline"], 65, 300, 38, 590, center=True, room=150, at=.1)
            if visual == "gauge":
                art = Image.new("RGBA", (620, 450))
                ad = ImageDraw.Draw(art)
                ad.arc((20, 80, 600, 660), 195, 345, fill="#edc576", width=3)
                for i in range(25):
                    a = math.radians(195 + i * 150 / 24)
                    x, y = 310 + math.cos(a) * 290, 370 + math.sin(a) * 290
                    x2, y2 = 310 + math.cos(a) * 270, 370 + math.sin(a) * 270
                    ad.line((x, y, x2, y2), fill="#ead39c", width=2)
                add(art, 50, 460, .4, "pop")
            else:
                art = illustration(visual, style, face).resize((430, 326), Image.Resampling.LANCZOS)
                glow = Image.new("RGBA", (620, 470))
                gd = ImageDraw.Draw(glow)
                gd.ellipse((180, 90, 440, 390), fill=(30, 227, 156, 60))
                glow = glow.filter(ImageFilter.GaussianBlur(45))
                add(glow, 50, 455, .3, "fade")
                add(art, 145, 520, .4, "float", 0, .035)
            txt(scene["body"], 75, 940, 29, 570, color=accent, center=True, room=165, at=1.15)
    else:  # cosmic-cartoon
        txt(scene["headline"], 44, 175, 39, 632, room=200, at=.05)
        label = textbox(scene["label"], face, 19, 590, base, maximum_height=55)
        marker = Image.new("RGBA", (620, label.height + 16), accent)
        marker.paste(label, (15, 8), label)
        add(marker, 44, 358, .35, "wipe", -1)
        if visual == "chat":
            panel = Image.new("RGBA", (636, 590), "#f8edce")
            pd = ImageDraw.Draw(panel)
            pd.rounded_rectangle((18, 20, 618, 73), 10, fill="#efe1b9")
            title = textbox("Gonanku  /  storyboard", face, 16, 560, "#302d2a", maximum_height=40)
            panel.paste(title, (35, 37), title)
            pd.rounded_rectangle((24, 100, 612, 184), 12, fill="#fffcf1")
            prompt = textbox(scene["body"], face, 22, 544, "#302d2a", maximum_height=65)
            panel.paste(prompt, (43, 115), prompt)
            pd.rounded_rectangle((24, 214, 612, 563), 10, fill="#132747")
            art = illustration("road", style, face).resize((588, 345), Image.Resampling.LANCZOS)
            panel.paste(art, (24, 214), art)
            add(panel, 42, 470, .55, "pop", -1)
        else:
            art = illustration("road" if visual in ("road", "moon") else visual, style, face).resize((620, 470), Image.Resampling.LANCZOS)
            panel = Image.new("RGBA", (650, 500), "#fff0ca")
            panel.paste(art, (15, 15), art)
            add(panel, 35, 485, .4, "pop", -2 if index % 2 == 0 else 2, .02)
            txt(scene["body"], 60, 1055, 26, 600, color=ink, center=True, room=120, at=1.05)
    return Scene(bg, layers, style, visual, index, scene["duration"])


def paste_layer(im, layer, t):
    elapsed = t - layer.at
    if elapsed < 0:
        return
    p = ease(elapsed / .55)
    image = layer.image
    x, y = layer.x, layer.y
    if layer.motion == "wipe":
        image = image.crop((0, 0, max(1, round(image.width * p)), image.height))
    else:
        zoom = 1 + layer.zoom * min(1, elapsed / 5)
        if layer.motion == "pop":
            zoom *= .88 + .12 * p + .025 * math.sin(min(1, elapsed / .7) * math.pi)
        if abs(zoom - 1) > .001:
            size = (max(1, round(image.width * zoom)), max(1, round(image.height * zoom)))
            image = image.resize(size, Image.Resampling.BICUBIC)
            x -= (size[0] - layer.image.width) // 2
            y -= (size[1] - layer.image.height) // 2
        if layer.motion in ("rise", "pop", "float"):
            y += round((1 - p) * 35)
        if layer.motion == "float":
            y += round(math.sin(elapsed * 1.65) * 7)
        if layer.motion == "slide":
            x += round((1 - p) * 85)
        if layer.angle:
            rotated = image.rotate(layer.angle * (.85 + .15 * p), Image.Resampling.BICUBIC, expand=True)
            x -= (rotated.width - image.width) // 2
            y -= (rotated.height - image.height) // 2
            image = rotated
    if p < 1 and layer.motion != "wipe":
        image = image.copy()
        image.putalpha(image.getchannel("A").point(lambda a: round(a * p)))
    im.paste(image, (round(x), round(y)), image)


def frame(scene, width, height, local, absolute, total, footage=None):
    im = scene.background.copy() if footage is None else ImageOps.fit(footage, (720, 1280), method=Image.Resampling.BICUBIC)
    if footage is not None:
        shade = Image.new("RGBA", im.size)
        sd = ImageDraw.Draw(shade)
        for y in range(1280):
            strength = 100 if y < 350 else round(160 * max(0, (y - 800) / 480))
            sd.line((0, y, 720, y), fill=(24, 13, 2, strength))
        im.paste(shade, (0, 0), shade)
    d = ImageDraw.Draw(im)
    rng = random.Random(311)
    if scene.style in ("aurora-story", "cosmic-cartoon"):
        for i in range(95):
            x = rng.uniform(12, 708)
            y = (rng.uniform(0, 1280) - absolute * (2 if scene.style == "aurora-story" else 5)) % 1280
            pulse = .5 + .5 * math.sin(absolute * 1.8 + i)
            color = tuple(round(c * (.35 + .6 * pulse)) for c in (170, 210, 210))
            r = 1 if i % 8 else 2
            d.ellipse((x - r, y - r, x + r, y + r), fill=color)
            if scene.style == "cosmic-cartoon" and i % 15 == 0:
                d.line((x - 4, y, x + 4, y), fill=color)
                d.line((x, y - 4, x, y + 4), fill=color)
        if scene.style == "aurora-story":
            for i in range(12):
                x = (rng.randrange(720) + absolute * (3 + i % 3)) % 720
                y = (rng.randrange(700) + 480 - absolute * 3) % 1200
                r = 9 + i % 4 * 5
                d.polygon([(x, y - r), (x + r, y), (x, y + r), (x - r, y)], fill="#124d4c")
    for layer in scene.layers:
        paste_layer(im, layer, local)
    d = ImageDraw.Draw(im)
    if scene.visual == "gauge" and scene.style == "aurora-story" and local > .65:
        a = math.radians(200 + 135 * ease((local - .65) / 2))
        d.line((360, 830, 360 + math.cos(a) * 263, 830 + math.sin(a) * 263), fill="#f4d99b", width=3)
        d.ellipse((354, 824, 366, 836), fill="#f4d99b")
    if scene.visual == "road" and scene.style == "cosmic-cartoon" and local > .7:
        x = round(95 + (local * 50) % 400)
        y = 901
        d.rounded_rectangle((x, y, x + 112, y + 38), 12, fill="#dd6951")
        d.polygon([(x + 23, y), (x + 40, y - 27), (x + 80, y - 27), (x + 99, y)], fill="#e58c63")
        d.polygon([(x + 41, y - 23), (x + 76, y - 23), (x + 90, y - 4), (x + 29, y - 4)], fill="#b6d4d5")
        for wx in (x + 25, x + 90):
            d.ellipse((wx - 11, y + 26, wx + 11, y + 48), fill="#111c2a")
            d.ellipse((wx - 5, y + 32, wx + 5, y + 42), fill="#d9dcd3")
    # Very short dip-to-background between scenes instead of slideshow cuts.
    fade = min(1, local / .12, max(0, (scene.duration - local) / .16))
    if fade < 1:
        im = Image.blend(Image.new("RGB", im.size, PALETTES[scene.style][0]), im, fade)
    if im.size != (width, height):
        im = im.resize((width, height), Image.Resampling.LANCZOS)
    return im
