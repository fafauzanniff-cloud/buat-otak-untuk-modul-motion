# Selamat datang di Modul Gonanku v2

Modul ini untuk niche **edukasi dan storytelling**. Kamu bisa mulai tanpa API key.

1. Buka folder **chatgpt**.
2. Buka **INSTRUKSI-GONANKU.md**, salin isinya ke Instructions pada Custom GPT atau Project ChatGPT bernama **Modul Gonanku**.
3. Tambahkan empat berkas lain di folder itu sebagai Knowledge/file proyek, termasuk **GAYA-REFERENSI-GONANKU.md**. Untuk GPT lama, ganti Instructions dan Knowledge dengan versi baru. Panduan ada di **docs/PASANG-DI-CHATGPT.md**.
4. Mulai dengan pesan:

> Gonanku, buat storytelling edukatif tentang [topik], gaya koran seperti referensi Konsisten Bukan Kaku. Audiens [isi audiens], tujuan [iklan atau produk digital]. Untuk sekarang tanpa ElevenLabs.

Untuk membuat MP4, gunakan Codex pada repositori ini atau komputer yang sudah memasang kebutuhan di **README.md**. Minta:

> Buat naskah dan storyboard JSON dari ide nomor satu. Pakai preset koran-vintage, variasikan split, hero, quote, dan recipe. Validasi lalu render dengan engine Gonanku.

Di paket lengkap:

- **contoh-hasil/koran/video.mp4** — adaptasi 68,4 detik, audio asli referensi.
- **contoh-hasil/aurora/video.mp4** — adaptasi 62,1 detik, audio asli referensi.
- **contoh-hasil/kartun/video.mp4** — contoh kartun 18 detik, tanpa suara.
- **references/** — lembar frame referensi pengguna dan metadata untuk menjaga arah visual.

Ganti gaya dengan menyebut **koran**, **aurora**, **kartun**, atau **presenter hangat**. Template cerita baru ada di examples/. Untuk presenter, gunakan rekamanmu sendiri yang bersih; pemisahan badan/outline otomatis belum tersedia. Adaptasi bukan salinan identik piksel. Jangan memakai audio cerita referensi untuk cerita baru.

Jangan unggah API key ke chat, Knowledge, atau repositori. Produk digitalmu belum ditentukan sehingga tidak ada harga/testimoni/tautan penjualan yang diada-adakan. Modul belum terpasang otomatis di akun ChatGPT; langkah di atas memasangnya.
