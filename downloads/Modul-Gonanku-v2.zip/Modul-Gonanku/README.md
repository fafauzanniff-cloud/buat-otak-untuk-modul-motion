# Modul Gonanku v2

Studio pribadi untuk ide, naskah storytelling edukatif, dan video motion dengan ChatGPT sebagai partner kreatif. Tujuan: konten orisinal untuk pendapatan iklan/AdSense dan produk digital. Tidak menjanjikan viral, persetujuan monetisasi, atau penghasilan tertentu.

## Mulai di ChatGPT

Ikuti [panduan pemasangan](docs/PASANG-DI-CHATGPT.md). Salin `chatgpt/INSTRUKSI-GONANKU.md` ke Instructions Custom GPT, lalu unggah empat berkas pengetahuan lainnya di folder `chatgpt/`. Alternatif: gunakan ChatGPT Project. Untuk memperbarui GPT lama, ganti Instructions dan unggah ulang Knowledge versi ini.

## Empat gaya dari referensi pengguna

- **koran-vintage:** kertas, kolom koran, serif, aksen merah, cutout, kutipan, dan resep. Default kreatif untuk storytelling edukatif.
- **aurora-story:** latar gelap, cahaya emas/hijau, partikel, gauge bergerak, perisai, checklist, dan bulan.
- **cosmic-cartoon:** bintang, krem/kuning, kartu miring, mockup percakapan, dan mobil bergerak.
- **presenter-hangat:** footage nyata dengan judul krem, kartu dan panel. Memerlukan rekaman; belum ada masking/outline badan otomatis.

Lihat [analisis referensi](docs/REFERENSI-VISUAL.md) dan [perintah gaya](chatgpt/GAYA-REFERENSI-GONANKU.md). Engine mendukung resep yang dapat dipakai ulang, bukan hanya instruksi teks. Font dan ilustrasi digambar ulang; hasil tidak diklaim identik piksel dengan referensi. Preset menggunakan palet terkunci dari referensi; `brand.name` mengganti nama brand. Warna `brand` bebas hanya untuk preset classic lama.

Tidak membutuhkan Claude atau API OpenAI. Markdown ini bukan plugin atau slash-command yang otomatis terpasang. Fitur Custom GPT/Project mengikuti akses akunmu. ChatGPT membantu menyusun konten; render MP4 dijalankan lewat Codex atau engine lokal berikut.

## Render pertama tanpa API key

Kebutuhan: Python 3.10+, FFmpeg/ffprobe dengan encoder H.264 (`libx264`), font DejaVu Sans atau TTF sendiri, dan Pillow.

```bash
python3 -m pip install -r requirements.txt
python3 scripts/gonanku.py doctor
python3 scripts/gonanku.py validate examples/koran-vintage.json
python3 scripts/gonanku.py render examples/koran-vintage.json --width 720 --fps 30 --out output/koran-baru
# Ganti gaya cukup dengan memakai salah satu contoh berikut
python3 scripts/gonanku.py render examples/aurora-story.json --width 720 --out output/aurora-baru
python3 scripts/gonanku.py render examples/cosmic-cartoon.json --width 720 --out output/kartun-baru
```

Hasil: `video.mp4`, `cover.png`, `captions.srt`, `naskah.txt`, `upload.md`, dan `manifest.json`. Contoh baru 18 detik, empat komposisi. **Draft tanpa suara** sampai ada audio. SRT mengikuti scene, bukan alignment kata otomatis. `examples/demo.json` mempertahankan template classic versi pertama untuk kompatibilitas; bukan gaya default yang dianjurkan lagi.

Tanpa `--width`, portrait menjadi 1080×1920 dan landscape 1920×1080. Rasio mengikuti `format` JSON. Jika perlu, gunakan `--font /lokasi/font.ttf`. Teks yang melampaui area ditolak.

Preset referensi khusus portrait; komposisi dasar 720×1280 mengikuti video acuan dan diskalakan saat ekspor. `classic` tetap mendukung landscape. Untuk rekaman presenter:

```bash
python3 scripts/gonanku.py render examples/presenter-hangat.json --footage rekaman-sendiri.mp4 --width 720 --out output/presenter-baru
```

Footage harus minimal sepanjang storyboard. Audio aslinya otomatis dipakai jika tersedia; `--audio` dapat menggantinya. `--footage-start 3` mulai dari detik ketiga; audio asli mengikuti posisi yang sama. Crop terpusat 9:16, tanpa tracking wajah. Gunakan footage tanpa caption bawaan; engine tidak menghapus teks atau memisahkan badan dari background.

## Contoh adaptasi yang dibundel

Dalam ZIP v2: `contoh-hasil/koran/` (68,4 detik) dan `contoh-hasil/aurora/` (62,1 detik) menggunakan **audio asli referensi unggahan** untuk perbandingan visual. `contoh-hasil/kartun/` (18 detik) tanpa suara. Ilustrasi digambar ulang, identitas modul menjadi Gonanku. Audio referensi bukan TTS baru dan bukan suara pengguna. SRT/naskah kedua adaptasi bersuara adalah petunjuk teks layar, bukan transkrip verbatim. Untuk cerita baru gunakan empat template gaya 18 detik, ganti naskah, lalu rekam atau buat audio sendiri.

## Suara ElevenLabs (opsional)

Simpan `ELEVENLABS_API_KEY` secara aman di Secrets lingkungan atau environment terminal; jangan di chat, JSON, atau Git. `ELEVENLABS_VOICE_ID` adalah ID suara yang berhak kamu gunakan. Periksa ketentuan komersial dan paket ElevenLabs terbaru.

```bash
# Estimasi karakter, tanpa jaringan atau kredit
python3 scripts/gonanku.py voice examples/koran-vintage.json
# Setelah memeriksa estimasi dan mengisi kedua variabel
python3 scripts/gonanku.py voice examples/koran-vintage.json --execute --out output/narasi.mp3
# Atau gunakan rekaman sendiri
python3 scripts/gonanku.py render examples/koran-vintage.json --audio output/narasi.mp3 --out output/bersuara
```

Jumlah karakter bukan harga pasti. Sesuaikan `duration` setiap scene dengan rekaman; renderer menolak selisih durasi total di atas 0,5 detik agar suara tidak terpotong diam-diam. Penyelarasan per kata belum tersedia.

## Lewat Codex

> Gonanku, buat storytelling edukatif 45 detik tentang [topik], gaya koran seperti referensi Konsisten Bukan Kaku. Ikuti examples/koran-vintage.json, variasikan adegan, validasi, lalu render tanpa ElevenLabs dulu.

Panduan: [alur kreator](docs/ALUR-KREATOR.md), [skema storyboard](docs/STORYBOARD.md). Tes: `python3 -m unittest discover -s tests -v`.

## Batas versi ini

- Belum ada generasi gambar/video AI, transkrip otomatis, masking badan, atau kloning seluruh keyframe asli. Scene, ilustrasi, dan overlay tersedia sesuai daftar preset.
- Tidak ada posting otomatis, pengambilan statistik akun, musik stok, atau voice cloning otomatis.
- ChatGPT biasa tidak otomatis mengakses Secrets Codex. Fitur eksekusi kode Custom GPT tidak menjamin FFmpeg/font tersedia; gunakan Codex/lokal bila render tidak didukung.
- Produk, harga, dan testimoni tidak akan diada-adakan. Produk contoh harus diganti sebelum menjadi penawaran nyata.

## Asal implementasi

Kode dan panduan Gonanku ditulis baru. “Jipraks Content Engine” dari unggahan pengguna dipelajari sebagai referensi kebutuhan, tidak disalin ke paket ini. Lisensi arsip asli tetap berlaku atas arsip tersebut. Dependensi Pillow dan FFmpeg mengikuti lisensinya masing-masing. Special Elite dan Lilita One dibundel dari repositori resmi Google Fonts bersama lisensi dan provenance di assets/fonts/; font sistem lain tidak dibundel.
