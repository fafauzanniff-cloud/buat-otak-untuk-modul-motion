# Referensi visual pengguna

Contact sheet dari empat video unggahan disimpan agar arah visual dapat ditinjau kembali. Lihat docs/REFERENSI-VISUAL.md. Ini materi acuan pengguna, bukan aset untuk disisipkan otomatis ke konten baru. File video asli tidak dibundel. Metadata tidak menyimpan path sesi atau key.

Untuk menambah referensi baru: simpan contact sheet, catat nama/durasi/rasio/fps, analisis komposisi dan ritme, lalu uji render berdampingan sebelum mengubah preset.
