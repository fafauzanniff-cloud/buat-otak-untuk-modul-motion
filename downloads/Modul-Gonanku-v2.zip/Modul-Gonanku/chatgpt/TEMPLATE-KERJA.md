# Template kerja Gonanku

## Brief

- Audiens dan masalah:
- Topik/pelajaran:
- Platform, format, durasi:
- Tujuan: iklan / produk digital / komunitas:
- Jenis cerita: nyata bersumber / ilustrasi / fiksi:
- Produk dan URL yang sudah ada (boleh kosong):
- Bukti/sumber:
- Gaya bahasa dan warna:
- CTA tunggal:

## Kartu ide

Judul kerja | Hook | Premis | Pelajaran | Bukti | Visual utama | Tujuan | CTA

## Naskah dan storyboard

Scene | Durasi | Narasi | Teks layar | Gerakan | Aset/hak pakai | Sumber

Setelah tabel, keluarkan JSON sesuai PENGETAHUAN-MOTION.md jika akan dirender. Tandai asumsi dan fakta yang belum diverifikasi di luar naskah dan di bagian assumptions.

## Pemeriksaan sebelum upload

- Hook dijawab; cerita dan klaim tidak menyesatkan.
- Label ilustrasi/fiksi jelas; sumber faktual dicatat.
- Teks terbaca, tidak keluar layar, tidak tertutup UI platform.
- Narasi sinkron dan terdengar; draft silent tidak dianggap final bersuara.
- Caption/SRT dicek ulang, hak suara/gambar/musik jelas.
- CTA sesuai produk nyata, URL diuji manual.
- Ketentuan monetisasi dan label konten sintetis platform diperiksa.

## Arsip manual

```csv
id,tanggal_wib,platform,judul,tujuan,hook,cta,url,status,views,avg_watch_seconds,clicks,landing_visits,sales,revenue,currency
```

Nilai kosong berarti belum ada data, bukan nol. Jangan memasukkan key atau data pribadi pelanggan.

## Contoh prompt

“Gonanku, buat 10 ide storytelling edukatif tentang kebiasaan belajar. Audiens pelajar, durasi 45 detik, tujuan iklan. Bedakan cerita ilustrasi dan fakta.”

“Gonanku, ubah ide nomor dua jadi naskah, storyboard, lalu JSON portrait. Tanpa ElevenLabs dulu.”

“Gonanku, buat tiga CTA untuk ebook saya [deskripsi asli produk]. Tidak perlu menjanjikan hasil atau membuat harga.”

“Gonanku, evaluasi CSV ini. Sebutkan data yang belum ada dan satu eksperimen yang paling masuk akal.”
