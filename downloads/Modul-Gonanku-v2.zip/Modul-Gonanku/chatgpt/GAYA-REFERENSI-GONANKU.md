# Gaya referensi Gonanku v2 — wajib dibaca untuk video motion

Pengguna tidak menyukai output awal berupa slide teks. Default motion sekarang **koran-vintage** untuk cerita edukatif, bukan template classic. Pilih **aurora-story** bila cerita reflektif/emosional, **cosmic-cartoon** untuk explainer kartun, dan **presenter-hangat** untuk rekaman manusia. Jangan menggabungkan semua gaya dalam satu video kecuali diminta.

| Permintaan pengguna | preset JSON | Bentuk adegan |
|---|---|---|
| gaya koran / seperti Konsisten Bukan Kaku | koran-vintage | potongan ilustrasi, judul serif, aksen merah, kutipan, kartu resep |
| gaya hijau / seperti Nggak Semua Orang Sanggup | aurora-story | cahaya emas/hijau, partikel, teks lapang, gauge/perisai/checklist/bulan |
| gaya kartun / seperti Cuma Ngobrol Jadi Video | cosmic-cartoon | bintang biru, krem/kuning, kartu percakapan, kartun jalan |
| gaya presenter hangat | presenter-hangat | footage asli + judul krem, kartu miring, panel informasi |

Engine mendukung field root `preset`, scene `layout`, `visual`, dan opsional `items`. Layout: hero, split, statement, quote, recipe, checklist. Koran mendukung seluruh layout tersebut; aurora: hero, statement, checklist; cosmic dan presenter menggunakan komposisi kartu/hero atau statement. Jangan mengklaim layout quote khusus ada pada semua preset.

Visual tersedia: lantern (lampu), gears (roda gigi), track (lapangan), care (perawatan), pot (panci/rendang), recipe, quote, gauge, shield, moon, checklist, road, chat, cards, book. Ilustrasi tetap memakai palet preset; mapping yang paling khas: koran lantern/gears/track/care/pot; aurora gauge/shield/moon/checklist; cosmic road/chat/book; presenter cards/book/recipe. `recipe/quote/cards` menggunakan ikon catatan; `checklist` gunakan layout checklist untuk daftar aktual. Gauge bergerak khusus aurora, mobil bergerak khusus road di cosmic.

Satu scene harus punya tugas visual selain menampilkan paragraf. Variasikan 4–6 komposisi. Highlight satu konsep, beri jeda setelah informasi utama. Teks layar lebih pendek daripada narasi. Naskah cerita harus tetap orisinal dan sesuai sumber. Gaya visual bisa mengikuti referensi sangat dekat, tetapi jangan menyebut gambar ulang sebagai salinan identik. Jangan menambahkan logo/akun/harga/testimoni kreator referensi ke konten baru.

## Contoh perintah pengguna

“Gonanku, buat cerita edukatif 45 detik tentang [topik], gaya koran seperti referensi Konsisten Bukan Kaku. Pakai lampu, roda gigi, kutipan, dan kartu resep. Buat JSON dan render.”

“Gonanku, pakai gaya aurora seperti video Nggak Semua Orang Sanggup. Buka dengan gauge emas, lanjut perisai hijau, checklist, lalu bulan. Ceritanya tentang [topik].”

“Gonanku, gaya kartun langit berbintang. Satu pertanyaan, kartu percakapan, adegan bergerak, penutup. Topik [topik].”

“Gonanku, edit rekaman saya dengan presenter-hangat. Pakai footage bersih ini dan judul berikut. Jangan gunakan wajah dari referensi sebagai presenter saya.”

Contoh JSON root menambahkan `"preset": "koran-vintage"`. Contoh scene:

```json
{"duration":5,"layout":"split","visual":"lantern","label":"CERITA ILUSTRASI","headline":"Mulai satu langkah.","body":"Pilih tindakan yang bisa dicoba hari ini.","narration":"Dalam cerita ini, Dina mulai dari satu langkah sederhana."}
```

Daftar: `"layout":"recipe", "items":["Pilih satu tugas","Sediakan waktu","Evaluasi besok"]`. Maksimal tiga item, masing-masing 50 karakter. Tidak ada path media atau API key di JSON.

Aurora dapat memakai `"show_label":false` untuk komposisi yang lebih lapang. Pada layout statement, `"body_emphasis":true` membuat kalimat penutup lebih besar. Misalnya headline “Tapi justru di situlah”, body “pahalanya.”. Nilainya boolean, bukan teks. Scene dengan visual gauge memakai cahaya emas di tengah; scene lain memakai aurora hijau.

Presenter memerlukan `--footage file.mp4`; tidak otomatis membuat manusia, menghapus caption bawaan, atau memisahkan badan. Jika alat render tidak ada, keluarkan storyboard dan instruksi menjalankan engine; jangan mengklaim sudah membuat MP4. Tanpa audio asli/rekaman/TTS, hasil silent. Untuk cerita baru jangan memakai narasi referensi yang tidak sesuai.
