# Edukasi, storytelling, dan pendapatan

## Dua jalur yang saling mendukung

**Iklan/AdSense:** bangun seri edukatif yang punya nilai orisinal: penjelasan, riset, contoh, atau perspektif kreator. Gunakan cerita untuk mengantar gagasan dan menjawab hook. Pilih CTA ke video lanjutan atau playlist. AdSense biasanya terkait ekosistem Google/YouTube; program iklan platform lain memiliki syarat berbeda. Verifikasi kebijakan resmi terbaru untuk platform dan akun, jangan menjanjikan kelulusan.

**Produk digital:** pilih masalah yang memang dibantu produk. Beri solusi berguna di konten, tunjukkan pemakaian produk nyata, lalu satu CTA yang jelas. Jangan membuat kelangkaan palsu, testimoni rekaan, harga, hasil, tautan checkout, atau klaim penghasilan yang belum diberikan. Jika produk belum ditentukan, bantu riset masalah dan ide produk sebagai hipotesis, bukan penawaran siap jual.

## Pola cerita

1. Tokoh/kondisi yang relevan, label fiksi bila ilustrasi.
2. Masalah atau pertanyaan konkret.
3. Percobaan dan konsekuensi.
4. Titik balik berupa keputusan atau penjelasan.
5. Pelajaran yang sesuai bukti, tidak digeneralisasi berlebihan.
6. Satu tindakan berikutnya.

Cerita nyata: minta sumber/izin bila diperlukan, jangan mengarang dialog dan mengklaimnya kutipan. Cerita sejarah: bedakan catatan sumber dari rekonstruksi. Topik kesehatan, keuangan, atau hukum: hindari saran personal tanpa konteks; verifikasi sumber yang sesuai.

## Evaluasi berdasarkan data pengguna

Catat platform, tanggal/rentang data, ID konten, panjang video, impressions, views, klik tujuan, kunjungan halaman, transaksi, pendapatan, dan definisi tiap metrik. Jangan mencampurkan denominator dari platform berbeda.

- CTR thumbnail = klik dari impressions / impressions × 100%, hanya jika definisinya cocok.
- Persentase durasi ditonton = rata-rata waktu tonton / durasi × 100%. Loop bisa membuat nilai di atas 100%.
- CTR tautan = klik tautan / jumlah tampilan yang relevan × 100%, sebutkan denominator.
- Konversi halaman = transaksi / kunjungan halaman × 100%.
- Pendapatan per seribu views = pendapatan yang benar-benar tercatat / views × 1000; bukan CPM iklan dan bukan ramalan.

Jika denominator nol/data hilang, tulis “belum dapat dihitung”. Korelasi bukan bukti penyebab. Bandingkan format dan periode yang sebanding. Hipotesis eksperimen: ubah satu faktor, tentukan metrik dan periode, catat hasil; jangan menjamin perbedaan statistik dari sampel kecil.

## Rekap publikasi manual

Simpan judul, tanggal Asia/Jakarta, tujuan bisnis, premis, hook, CTA, URL (hanya sesudah diposting), sumber, hak aset, dan metrik. Gunakan TEMPLATE-KERJA.md. ChatGPT tidak otomatis mengetahui statistik atau menyimpan arsip lintas sesi.
