# Pengetahuan motion Gonanku

Engine v2 menggunakan Python, Pillow, dan FFmpeg. Baca GAYA-REFERENSI-GONANKU.md: empat preset baru memakai ilustrasi berlapis, animasi masuk, tekstur/latar, partikel, gauge atau mobil bergerak, serta overlay footage untuk presenter. Tidak menyediakan karakter 3D, masking badan, generasi gambar AI, atau sinkron kata otomatis. Classic lama hanya dipakai bila diminta.

JSON memakai struktur ini (tanpa komentar di dalam JSON):

```json
{
  "title": "Satu langkah untuk mulai",
  "format": "portrait",
  "goal": "iklan",
  "preset": "koran-vintage",
  "brand": {"name": "GONANKU", "background": "#101827", "accent": "#C4F06B", "text": "#F6F7FB"},
  "scenes": [
    {"duration": 5, "layout": "split", "visual": "lantern", "label": "CERITA ILUSTRASI", "headline": "Mulai dari satu langkah", "body": "Contoh sederhana untuk dicoba hari ini.", "narration": "Ini cerita ilustrasi tentang seseorang yang mencoba memulai dari satu langkah."}
  ],
  "post": {"caption": "Cerita ilustrasi, bukan testimoni.", "hashtags": ["#CeritaEdukasi"]},
  "sources": [],
  "assumptions": ["Audiens belum ditentukan."]
}
```

`format`: portrait (9:16) atau landscape (16:9). `goal`: iklan, produk_digital, atau komunitas. `duration`: 0,5–60 detik/scene, total maksimal 600 detik, maksimal 60 scene. Warna harus #RRGGBB. Headline maksimal 100 karakter, body 180, label 36, narasi 1000. Batas karakter bukan jaminan muat; renderer memeriksa layout. Utamakan headline 3–8 kata, body 8–18 kata. Narasi boleh lebih lengkap.

Saran: short 20–60 detik, cerita panjang dipecah per bab dan divalidasi ulang. Tidak semua format memenuhi syarat monetisasi platform. Estimasi baca 120–160 kata/menit hanyalah titik awal; cek rekaman sebenarnya.

Alur: simpan JSON → `python3 scripts/gonanku.py validate <json>` → render draft → periksa visual → tambahkan audio legal → cocokkan durasi scene → render final. `render` membuat MP4, cover PNG, SRT scene, transkrip, paket upload, dan manifest. Tidak menambahkan suara otomatis. Audio harus cocok dengan durasi total dalam toleransi 0,5 detik. Periksa sinkronisasi setiap scene secara manual.

Keempat preset referensi hanya portrait. Palet dikunci mengikuti preset (brand.name tetap dapat diganti); brand.background/accent/text digunakan bebas pada classic saja. Periksa safe area platform tujuan karena UI dapat berubah. Satu informasi utama per scene. Jangan memakai gerakan sekadar memenuhi layar.
