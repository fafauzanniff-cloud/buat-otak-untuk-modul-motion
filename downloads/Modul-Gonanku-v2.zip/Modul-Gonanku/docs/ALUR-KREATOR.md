# Alur harian edukasi + storytelling

1. Pilih satu pertanyaan audiens dan satu tujuan bisnis. Profil niche sudah diketahui; lengkapi audiens, platform, dan produk bila ada.
   Pilih satu preset referensi: koran-vintage (default), aurora-story, cosmic-cartoon, atau presenter-hangat. Baca GAYA-REFERENSI-GONANKU.md; jangan kembali ke slide classic tanpa permintaan.
2. Kumpulkan pengalaman/sumber. Tentukan cerita nyata atau ilustrasi sejak awal.
3. Minta Gonanku membuat beberapa premis; pilih satu berdasarkan manfaat, bukti, dan kemampuan produksinya.
4. Tulis narasi: hook, konteks, konflik, titik balik, pelajaran, satu CTA. Baca keras-keras untuk memeriksa durasi.
5. Buat scene dan JSON, validasi, render draft silent atau gunakan audio rekaman sendiri. Periksa cover dan beberapa frame video.
6. Bila memakai ElevenLabs, periksa teks/model/jumlah karakter dahulu. Setelah diizinkan dan key tersedia, buat suara. Sesuaikan timeline dengan audio dan render ulang.
7. Periksa hak aset, sumber, SRT, sinkronisasi, caption, tautan produk, dan kebijakan platform. Unggah secara manual.
8. Simpan catatan dan metrik aktual. Minta evaluasi dengan periode dan definisi metrik yang jelas.

Untuk AdSense/iklan, CTA dapat mengarah ke seri pembelajaran berikutnya. Untuk produk digital, tunjukkan manfaat produk yang memang ada dengan demonstrasi. Jangan menyisipkan penawaran palsu ketika produk belum ditentukan.

Arsip metrik manual dapat memakai header di TEMPLATE-KERJA.md. Retensi rendah bukan otomatis karena hook: durasi, audiens, distribusi, dan topik juga bisa berpengaruh. Uji satu perubahan yang masuk akal.
