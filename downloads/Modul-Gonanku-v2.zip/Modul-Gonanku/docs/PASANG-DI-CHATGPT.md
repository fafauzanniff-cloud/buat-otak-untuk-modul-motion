# Memasang Modul Gonanku di ChatGPT

## Pilihan A — Custom GPT

Gunakan editor pembuatan GPT bila fitur tersedia pada akunmu. Nama: **Modul Gonanku**. Deskripsi: **Partner edukasi dan storytelling untuk ide, naskah, storyboard motion, dan konten produk digital.**

1. Salin seluruh isi `chatgpt/INSTRUKSI-GONANKU.md` ke kolom Instructions.
2. Unggah `GAYA-REFERENSI-GONANKU.md`, `PENGETAHUAN-MOTION.md`, `PANDUAN-MONETISASI.md`, dan `TEMPLATE-KERJA.md` sebagai Knowledge. Jangan unggah API key atau arsip kelas asli. Untuk upgrade GPT lama, ganti Instructions dan Knowledge lama dengan versi ini.
3. Jika tersedia, aktifkan browsing untuk cek fakta dan analisis data/eksekusi kode untuk membaca JSON/CSV. Ini tidak otomatis menyediakan FFmpeg atau akses Codex.
4. Tambahkan pembuka percakapan: “Mulai profil kreator saya”, “Buat ide storytelling edukatif”, “Buat storyboard motion”, dan “Evaluasi konten saya”.
5. Uji dengan meminta cerita ilustrasi 30 detik. Pastikan status ilustrasi disebut, satu pelajaran, satu CTA, dan tidak mengaku sudah merender bila belum ada file.
6. Simpan untuk penggunaan pribadi dahulu. Nama tombol/menu dapat berbeda menurut versi aplikasi dan akses akun.

Tidak diperlukan Custom Actions, API OpenAI, atau API ElevenLabs untuk tahap ide/naskah. Instruksi tidak menginstal plugin dan tidak mengubah model ChatGPT.

## Pilihan B — ChatGPT Project

Buat Project **Modul Gonanku**, isi Project instructions dengan berkas instruksi yang sama, dan tambahkan empat berkas pengetahuan. Unggah juga `brand/profil.json` bila ingin membawa profil proyek. Mulai chat di dalam Project itu. Jika fitur unggah/instruksi tidak tersedia, tempel instruksi dan brief dalam chat biasa; kemampuan file mengikuti akunmu.

## MP4 lewat Codex atau komputer

Instruksi dan Knowledge membantu menghasilkan JSON; engine Python membuat video. Di Codex gunakan repositori ini dan perintah README. Secara lokal, ekstrak ZIP, pasang Python/FFmpeg/Pillow, lalu jalankan perintah README dari folder Gonanku. Windows dapat memakai `python` alih-alih `python3`; gunakan `--font` ke file TTF yang tersedia.

Jangan memasukkan key ke Knowledge atau percakapan. ElevenLabs memakai Secrets di lingkungan yang benar-benar mengeksekusi engine. Secrets Codex tidak otomatis tersedia di Custom GPT. Tidak perlu menyelesaikan ElevenLabs untuk membuat video silent atau memakai rekaman sendiri.
