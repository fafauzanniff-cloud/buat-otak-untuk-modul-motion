# Hasil validasi

## Versi 2 — berdasarkan empat referensi pengguna

- Empat referensi 720×1280, 30 fps dianalisis dari metadata dan contact sheet. Dua referensi storytelling diperiksa lebih rapat setiap dua detik. Contact sheet dan metadata portabel disimpan di references/; analisis di REFERENSI-VISUAL.md.
- Koran: 68,4 detik, 2052 frame; aurora: 62,1 detik, 1863 frame; kartun: 18 detik, 540 frame. Seluruhnya MP4 H.264 720×1280, 30 fps.
- Koran dan aurora menggunakan audio asli unggahan. Kartun tanpa suara. Tidak ada API berbayar atau voice cloning. Teks SRT/naskah kedua adaptasi bersuara adalah screen cue, bukan transkrip verbatim.
- Semua scene pada enam storyboard baru diperiksa layout-nya. Frame setiap scene dari hasil MP4 diperiksa untuk pemotongan teks dan kelengkapan ilustrasi.
- Tes mencakup render nyata classic portrait/landscape, alpha overlay pada footage sintetis, crop/trim, mux audio asli, penolakan footage pendek/hilang, semua layout contoh baru, determinisme dan pergerakan frame, validasi schema, serta pengamanan file lama dan dry-run tanpa jaringan.
- Hasil akhir: **21 tes lulus, 0 gagal, 0 dilewati**. `git diff --check` lulus. Special Elite dan Lilita One divalidasi dapat dimuat Pillow, lisensi serta SHA-256 unduhan disimpan di assets/fonts/.
- Presenter diuji dengan footage sintetis lokal; contoh render presenter manusia baru tidak dibundel. Engine belum memisahkan badan, tracking wajah, atau menghapus caption bawaan.
- Belum diuji: pemasangan di UI akun ChatGPT pengguna, koneksi ElevenLabs, instalasi Windows/macOS, publikasi, atau kelayakan monetisasi. Tidak ada klaim identik piksel/keyframe dengan sumber.

Build paket: setelah ketiga render berada di output/v2-koran, output/v2-aurora, output/v2-cosmic, jalankan `python3 scripts/package.py`. Paket tidak berisi .env, .git, cache, atau file video asli unggahan. Contact sheet acuan dan tiga hasil adaptasi dibundel.

## Versi 1 — catatan historis

Validasi dilakukan di lingkungan cloud proyek ini; belum merupakan pengujian instalasi pada semua sistem operasi atau publikasi lingkungan baru.

- Python 3.12.14, Pillow 12.3.0, FFmpeg/ffprobe, encoder libx264, dan font DejaVu Sans tersedia.
- `doctor` lulus untuk render tanpa API.
- Contoh: 5 scene, 24 detik, MP4 H.264 1080×1920 pada 24 fps, 576 frame. Tidak ada audio pada contoh yang dibundel.
- Cover serta frame dari semua scene diperiksa: label ilustrasi, headline, body, dan progress bar terbaca.
- 12 tes lulus, tidak ada yang dilewati: validasi input/durasi/kontras, dry-run tanpa jaringan, perlindungan file lama, render nyata portrait dan landscape, mux audio AAC lokal, penolakan audio yang tidak sesuai, dan penolakan teks melampaui layout.
- Tes audio menggunakan nada sintetis lokal; bukan suara ElevenLabs dan tidak memakai kredit.
- `git diff --check` lulus.

Belum diuji: koneksi ElevenLabs berkey, kualitas/sinkronisasi TTS nyata, pemasangan melalui UI Custom GPT, posting ke platform, kelayakan monetisasi, serta instalasi Windows/macOS. Tidak ada API key yang dimasukkan dan tidak ada akun yang diposting.

Build contoh lama (tidak dipakai packaging v2):

```bash
python3 scripts/gonanku.py render examples/demo.json --fps 24 --out output/demo-hd
```

Jika output/demo-hd sudah berisi file, jangan merender ulang ke folder yang sama; simpan revisi di folder lain atau arsipkan hasil sebelumnya.
