# Kontrak storyboard

Lihat `examples/koran-vintage.json` dan `chatgpt/PENGETAHUAN-MOTION.md`. Engine memerlukan semua kolom `title`, `format`, `goal`, `brand`, `scenes`, `post`, `sources`, `assumptions`. Tambahkan `preset` agar memakai empat gaya referensi; tanpa field ini engine mempertahankan classic lama.

Preset: koran-vintage, aurora-story, cosmic-cartoon, presenter-hangat, classic. Scene boleh menambahkan `layout`, `visual`, dan `items` sesuai GAYA-REFERENSI-GONANKU.md. Items 1–3 string maksimal 50 karakter. Preset referensi hanya portrait. Palet ditentukan preset, brand.name tetap bebas. Koran memakai Special Elite dan kartun Lilita One yang dibundel beserta lisensinya. Varian italic dicari di font sistem lalu fallback ke --font. Ini bisa menyebabkan perbedaan dari acuan.

Periksa dengan `python3 scripts/gonanku.py validate file.json`. Nomor scene ditampilkan pada error. Panjang teks dibatasi, durasi harus angka finite (bukan bool), dan warna harus hex enam digit. Field tambahan diabaikan; tidak menjalankan kode dari JSON.

`sources` berisi daftar string (misalnya URL + tanggal akses + klaim yang didukung). Daftar kosong diperbolehkan untuk cerita ilustrasi yang tidak memuat klaim eksternal. `assumptions` berisi batasan atau asumsi proyek; daftar kosong diperbolehkan. Caption SRT memakai `narration` dan durasi scene; teks bisa perlu dipecah lagi secara manual untuk subtitle yang lebih nyaman.

Saat render, durasi dibulatkan ke batas frame terdekat. Manifest menyimpan frames/fps dan ada/tidaknya audio. Audio opsional: dukungan format mengikuti FFmpeg. Durasi harus cocok ±0,5 detik; renderer tidak melakukan time-stretch atau alignment kata. Jangan menyebut sinkron otomatis. Sesuaikan setiap scene dengan rekaman lewat editor/pendengaran sebelum final.

Folder output baru harus kosong/tidak ada; renderer tidak menimpa hasil lama. Gunakan folder baru untuk tiap revisi. Jika render gagal, folder output tidak diisi hasil parsial. Headline/body mengecil seperlunya hingga batas keterbacaan, lalu ditolak jika tetap tidak muat.

`presenter-hangat` memerlukan --footage. Audio aslinya dipakai otomatis jika ada, dipotong mengikuti durasi storyboard dan --footage-start. --audio dapat menggantinya dan harus cocok ±0,5 detik. Footage harus cukup panjang. Engine tidak mengeksekusi path dari JSON; media hanya dari argumen CLI.

`subtitle_kind` opsional: narration (default) atau screen_text. Pada screen_text, SRT/naskah merupakan petunjuk teks layar, bukan transkrip. Ini dipakai pada dua adaptasi yang memakai audio asli referensi. Manifest menyimpan versi, preset, dan jenis subtitle.
