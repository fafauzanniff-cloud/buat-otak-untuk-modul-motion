# Referensi visual Gonanku v2

Empat video unggahan pengguna diperiksa lewat metadata, contact sheet 12 frame/video, dan frame setiap dua detik untuk kedua referensi storytelling. Ini analisis visual, bukan akses ke project/keyframe asli. Durasi gerak dan batas scene ditaksir dari frame; karakteristik suara tidak diukur.

| Referensi unggahan | Metadata terukur | Preset Gonanku | Ciri yang diadaptasi |
|---|---|---|---|
| Cuma ngobrol, jadi video | 23,126 dtk; 720×1280; 30 fps; audio | cosmic-cartoon | Langit biru, bintang, huruf krem, sorotan kuning, kartu miring, adegan kartun dan percakapan |
| Part 3-17 — Nggak Semua Orang Sanggup | 62,121 dtk; 720×1280; 30 fps; audio | aurora-story | Latar gelap, cahaya emas lalu hijau, partikel, ruang kosong, teks tengah, gauge, perisai, checklist, bulan |
| Berkas bernama AQMirfb… | 18,921 dtk; 720×1280; 30 fps; audio | presenter-hangat | Footage presenter, warna hangat, judul krem, kartu miring, panel informasi |
| Part 12-17 — Konsisten, Bukan Kaku | 68,393 dtk; 720×1280; 30 fps; audio | koran-vintage | Kertas krem, kolom koran, serif, aksen merah gelap, tepi sobek, lampu, roda gigi, lapangan, catatan/resep |

## Peta adegan untuk penggunaan berikutnya

**Koran:** pembuka dengan potongan ilustrasi → kontras konsep dengan roda gigi → contoh konkret → pengecualian/konteks → kutipan → rangkuman resep. Cutout muncul sekitar 0,4 detik setelah judul, penjelasan menyusul sekitar 1 detik. Jenis layout `split`, `hero`, `statement`, `quote`, `recipe`, `checklist`. Ada gerak naik, pop, sedikit putaran/zoom, wipe, dan transisi singkat. Ilustrasi digambar ulang secara programatik, bukan piksel asli.

**Aurora:** pembuka/tekanan dengan gauge emas → ikon perisai dan energi hijau → kalimat penekanan → kartu checklist → penutup reflektif dengan bulan. Sebagian adegan sengaja lapang. Partikel, diamond, twinkle, gauge bergerak, ikon mengambang, dan cahaya latar menjaga gerakan selama kalimat ditahan.

**Kartun:** satu pertanyaan → kartu percakapan → adegan visual → ajakan mencoba. Latar bintang bergerak, kartu krem muncul dengan tilt, mobil melintas. Mockup memakai nama Gonanku. Ini ilustrasi kemampuan engine, bukan bukti UI ChatGPT mengerjakan sesuatu otomatis.

**Presenter:** footage pengguna menjadi latar; judul/panel naik, kartu ilustrasi masuk dari sisi, teks penjelas di bagian bawah. Audio asli footage otomatis dipakai bila ada dan --audio tidak diberikan. Crop terpusat 9:16; tidak ada tracking wajah atau segmentasi badan. Untuk hasil bersih gunakan footage tanpa caption/logo bawaan. Engine tidak menghapus tulisan yang sudah menyatu dalam piksel video.

## Yang belum identik

Font/keyframe project asli tidak tersedia. Engine memakai Special Elite (koran) dan Lilita One (kartun) dari Google Fonts untuk mendekati tipografi, font sistem untuk varian lain, serta ilustrasi yang digambar ulang. Ritme dan layout diadaptasi, bukan salinan piksel. Belum ada motion blur fisik, masking badan otomatis, pemilihan multi-font per kata, sinkron kata otomatis, atau sound design baru. Tidak mengklaim hasil identik 100%.

## Audio pada contoh adaptasi

`output/v2-koran` dan `output/v2-aurora` memakai audio asli dari unggahan terkait; tidak ada voice clone, API berbayar, atau musik baru. Naskah dan SRT kedua contoh adalah petunjuk teks layar yang direkonstruksi dari frame, **bukan transkrip verbatim**. Paket contoh untuk evaluasi gaya; jangan menganggap suara dalam contoh sebagai suara milik Gonanku atau suara pengguna.

Untuk cerita baru: tulis naskah baru, isi scene, gunakan rekaman sendiri atau TTS yang sudah diizinkan. Jangan memakai ulang audio contoh untuk topik lain. Ketika meminta “ple ketiplek”, pertahankan palet, rasio, keluarga tipografi, alur gerak, komposisi, dan pacing acuan; periksa hasil berdampingan dan laporkan perbedaan, jangan menjanjikan identik tanpa pemeriksaan.
