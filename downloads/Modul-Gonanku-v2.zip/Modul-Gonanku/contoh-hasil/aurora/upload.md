# Adaptasi referensi — Nggak Semua Orang Sanggup

Status: DRAFT, belum dipublikasikan.

Preset: aurora-story

Tujuan: iklan

Contoh gaya Modul Gonanku. Adaptasi dari referensi unggahan pengguna; audio asli referensi dipakai untuk evaluasi.

#Gonanku #StorytellingEdukasi

Audio: tersedia; periksa sinkronisasi per scene

## Asumsi

- Audio berasal dari referensi unggahan, tidak dibuat ulang dengan AI.
- Naskah/SRT berisi petunjuk teks layar, bukan transkrip verbatim atau alignment kata.
- Timing ditaksir dari frame referensi; bukan salinan keyframe asli.

## Sumber

- Referensi video unggahan pengguna; lihat docs/REFERENSI-VISUAL.md.
