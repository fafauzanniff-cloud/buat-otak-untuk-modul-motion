import argparse
import contextlib
import copy
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
from scripts import gonanku as g


class StoryboardTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / "examples/demo.json").read_text())

    def test_demo_has_expected_scenes_and_duration(self):
        self.assertEqual(len(g.validate(self.data)["scenes"]), 5)
        self.assertEqual(sum(s["duration"] for s in self.data["scenes"]), 24)

    def test_invalid_durations_rejected(self):
        for duration in (True, 0, -1, float("nan"), float("inf"), "5", 61):
            with self.subTest(duration=duration):
                self.data["scenes"][0]["duration"] = duration
                with self.assertRaisesRegex(ValueError, "duration"):
                    g.validate(self.data)

    def test_missing_and_long_copy_rejected(self):
        del self.data["scenes"][0]["narration"]
        with self.assertRaisesRegex(ValueError, "narration"):
            g.validate(self.data)
        self.data["scenes"][0]["narration"] = "x" * 1001
        with self.assertRaisesRegex(ValueError, "narration"):
            g.validate(self.data)

    def test_contrast_and_invalid_color_rejected(self):
        for color in ("red", "#101827"):
            self.data["brand"]["text"] = color
            with self.assertRaises(ValueError):
                g.validate(self.data)

    def test_total_duration_cap(self):
        self.data["scenes"] = [copy.deepcopy(self.data["scenes"][0]) for _ in range(11)]
        for scene in self.data["scenes"]:
            scene["duration"] = 60
        with self.assertRaisesRegex(ValueError, "600"):
            g.validate(self.data)

    def test_dimensions_portrait_and_landscape(self):
        self.assertEqual(g.dimensions(self.data), (1080, 1920))
        self.data["format"] = "landscape"
        self.assertEqual(g.dimensions(self.data), (1920, 1080))
        with self.assertRaises(ValueError):
            g.dimensions(self.data, 541)

    def test_voice_default_never_calls_network(self):
        with patch.object(g.urllib.request, "build_opener", side_effect=AssertionError("Network called")), contextlib.redirect_stdout(io.StringIO()) as log:
            g.voice(self.data, argparse.Namespace(execute=False))
        self.assertIn("DRY RUN", log.getvalue())

    def test_missing_credentials_fail_without_network(self):
        with patch.dict(g.os.environ, {}, clear=True), patch.object(g.urllib.request, "build_opener", side_effect=AssertionError("Network called")), contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(ValueError, "pengaturan aman"):
                g.voice(self.data, argparse.Namespace(execute=True))

    def test_existing_voice_file_prevents_repeat_spending(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "old.mp3"
            out.write_bytes(b"existing")
            with patch.dict(g.os.environ, {"ELEVENLABS_API_KEY": "test-do-not-print", "ELEVENLABS_VOICE_ID": "test-voice"}), patch.object(g.urllib.request, "build_opener", side_effect=AssertionError("Network called")), contextlib.redirect_stdout(io.StringIO()) as log:
                with self.assertRaisesRegex(ValueError, "sudah ada"):
                    g.voice(self.data, argparse.Namespace(execute=True, out=str(out)))
            self.assertEqual(out.read_bytes(), b"existing")
            self.assertNotIn("test-do-not-print", log.getvalue())


@unittest.skipUnless(g.shutil.which("ffmpeg") and g.shutil.which("ffprobe"), "FFmpeg required for render integration")
class RenderTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / "examples/demo.json").read_text())
        self.data["scenes"] = [dict(duration=.5, label="ILUSTRASI", headline="Mulai kecil", body="Coba satu langkah.", narration="Coba satu langkah."), dict(duration=.5, label="PELAJARAN", headline="Lalu ulangi", body="Pilih tindakanmu.", narration="Lalu ulangi.")]

    def args(self, out, audio=None):
        return argparse.Namespace(width=320, fps=24, font=None, audio=audio, out=str(out))

    def test_real_video_both_ratios_and_outputs(self):
        with tempfile.TemporaryDirectory() as temp:
            for orientation in ("portrait", "landscape"):
                with self.subTest(orientation=orientation):
                    self.data["format"] = orientation
                    out = Path(temp) / orientation
                    with contextlib.redirect_stdout(io.StringIO()):
                        g.render(self.data, self.args(out))
                    info = g.probe(out / "video.mp4")
                    video = next(s for s in info["streams"] if s["codec_type"] == "video")
                    self.assertEqual(int(video["nb_frames"]), 24)
                    self.assertEqual(video["codec_name"], "h264")
                    self.assertAlmostEqual(float(info["format"]["duration"]), 1, places=2)
                    self.assertFalse(any(s["codec_type"] == "audio" for s in info["streams"]))
                    manifest = json.loads((out / "manifest.json").read_text())
                    self.assertFalse(manifest["audio"])
                    self.assertEqual(manifest["sha256"], g.hashlib.sha256((out / "video.mp4").read_bytes()).hexdigest())
                    self.assertIn("00:00:00,500 --> 00:00:01,000", (out / "captions.srt").read_text())
                    self.assertIn("TANPA SUARA", (out / "upload.md").read_text())
                    self.assertTrue((out / "cover.png").is_file())
                    with self.assertRaisesRegex(ValueError, "sudah berisi"):
                        g.render(self.data, self.args(out))

    def test_audio_mux_and_mismatch_rejection(self):
        with tempfile.TemporaryDirectory() as temp:
            audio = Path(temp) / "tone.wav"
            # Synthetic local test tone, not an external service or paid voice call.
            subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1", str(audio)], check=True)
            out = Path(temp) / "audio"
            with contextlib.redirect_stdout(io.StringIO()):
                g.render(self.data, self.args(out, str(audio)))
            info = g.probe(out / "video.mp4")
            self.assertTrue(any(s["codec_type"] == "audio" and s["codec_name"] == "aac" for s in info["streams"]))
            self.data["scenes"][0]["duration"] = 3
            with self.assertRaisesRegex(ValueError, "Durasi audio"):
                g.render(self.data, self.args(Path(temp) / "bad", str(audio)))
            self.assertFalse((Path(temp) / "bad").exists())

    def test_overflow_rejected_before_render(self):
        self.data["scenes"][0]["headline"] = "W" * 100
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "overflow"
            with self.assertRaisesRegex(ValueError, "tidak muat"):
                g.render(self.data, self.args(out))
            self.assertFalse(out.exists())


if __name__ == "__main__":
    unittest.main()
