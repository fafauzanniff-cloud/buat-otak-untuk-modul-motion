import argparse
import contextlib
import copy
import io
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from scripts import gonanku as g

ROOT = Path(__file__).resolve().parents[1]


class PresetTests(unittest.TestCase):
    def setUp(self):
        self.data = g.load(ROOT / "examples/koran-vintage.json")

    def test_all_six_new_storyboards_fit_at_native_resolution(self):
        for name in ("koran-vintage", "aurora-story", "cosmic-cartoon", "presenter-hangat", "adaptasi-koran", "adaptasi-aurora"):
            data = g.load(ROOT / f"examples/{name}.json")
            for n, scene in enumerate(data["scenes"]):
                with self.subTest(preset=name, scene=n):
                    card = g.scene_card(data, scene, n, 720, 1280, g.font_path())
                    image = g.frame(data, card, 720, 1280, 2.5, 2.5, 18)
                    self.assertEqual(image.size, (720, 1280))
                    self.assertEqual(image.mode, "RGB")

    def test_motion_is_deterministic_but_changes_over_time(self):
        data = g.load(ROOT / "examples/aurora-story.json")
        card = g.scene_card(data, data["scenes"][0], 0, 720, 1280, g.font_path())
        a = g.frame(data, card, 360, 640, 1, 1, 18).tobytes()
        b = g.frame(data, card, 360, 640, 1, 1, 18).tobytes()
        c = g.frame(data, card, 360, 640, 2, 2, 18).tobytes()
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)

    def test_unknown_preset_and_landscape_preset_rejected(self):
        self.data["preset"] = "invented"
        with self.assertRaisesRegex(ValueError, "preset"):
            g.validate(self.data)
        self.data["preset"] = "koran-vintage"
        self.data["format"] = "landscape"
        with self.assertRaisesRegex(ValueError, "portrait"):
            g.validate(self.data)

    def test_unknown_visual_and_layout_rejected(self):
        for field in ("visual", "layout"):
            data = copy.deepcopy(self.data)
            data["scenes"][0][field] = "invented"
            with self.assertRaisesRegex(ValueError, field):
                g.validate(data)

    def test_items_are_bounded(self):
        for items in ([], ["a"] * 4, ["x" * 51], "not-a-list"):
            self.data["scenes"][0]["items"] = items
            with self.assertRaisesRegex(ValueError, "items"):
                g.validate(self.data)

    def test_animation_flags_require_booleans(self):
        for field in ("show_label", "body_emphasis"):
            data = copy.deepcopy(self.data)
            data["scenes"][0][field] = "false"
            with self.assertRaisesRegex(ValueError, field):
                g.validate(data)

    def test_reference_sources_remain_usable_without_session_paths(self):
        metadata = json.loads((ROOT / "references/metadata.json").read_text())
        self.assertEqual(len(metadata), 4)
        for item in metadata:
            self.assertEqual(Path(item["file"]).name, item["file"])
            self.assertTrue((ROOT / "references" / item["contact_sheet"]).is_file())


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "FFmpeg required")
class FootageTests(unittest.TestCase):
    def setUp(self):
        self.data = g.load(ROOT / "examples/presenter-hangat.json")
        self.data["scenes"] = self.data["scenes"][:1]
        self.data["scenes"][0]["duration"] = 1

    def args(self, out, footage=None, start=0):
        return argparse.Namespace(width=320, fps=24, font=None, audio=None, footage=footage, footage_start=start, out=str(out))

    def test_missing_footage_fails_before_partial_output(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "missing"
            with self.assertRaisesRegex(ValueError, "memerlukan --footage"):
                g.render(self.data, self.args(out))
            self.assertFalse(out.exists())

    def test_real_footage_decode_overlay_trim_and_audio_mux(self):
        with tempfile.TemporaryDirectory() as temp:
            footage = Path(temp) / "source.mp4"
            subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=c=blue:s=320x568:r=24:d=2", "-f", "lavfi", "-i", "sine=frequency=440:duration=2", "-c:v", "libx264", "-threads", "2", "-pix_fmt", "yuv420p", "-c:a", "aac", str(footage)], check=True)
            out = Path(temp) / "render"
            with contextlib.redirect_stdout(io.StringIO()):
                g.render(self.data, self.args(out, str(footage), .5))
            info = g.probe(out / "video.mp4")
            self.assertTrue(any(s["codec_type"] == "audio" for s in info["streams"]))
            video = next(s for s in info["streams"] if s["codec_type"] == "video")
            self.assertEqual(int(video["nb_frames"]), 24)
            manifest = json.loads((out / "manifest.json").read_text())
            self.assertEqual(manifest["preset"], "presenter-hangat")
            self.assertTrue(manifest["audio"])
            with self.assertRaisesRegex(ValueError, "tidak cukup"):
                g.render(self.data, self.args(Path(temp) / "too-short", str(footage), 1.7))


if __name__ == "__main__":
    unittest.main()
